/* 
 * File:   p2_e3_b.c
 * Author: PABLO CUESTA, OLMAR ARRANZ
 *
 * Created on 25 de febrero de 2020, 10:33
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "stack.h"
#include "element.h"

int main(int argc, char** argv) {
    char string[] = "abc";
    Stack *s = NULL;
    int i, len;
    Status st = OK;
    Element *ele = NULL;

    if (!(s = stack_init())) return 1;

    len = strlen(string);

    if(!(ele=element_init())) st = ERROR;

    for (i = 0; i < len && st == OK; i++) {
        st = element_setInfo(ele, string + i);
        if(st == OK)
            st = stack_push(s, ele);
    }

    element_free(ele);

    if(st == ERROR){
        stack_free(s);
        return 1;
    }

    stack_print(stdout, s);

    fprintf(stdout, "Tamaño de la pila: %d\n", stack_size(s));

    while (stack_isEmpty(s) == FALSE){
        ele = stack_pop(s);
        printf("\nElemento extraído: ");
        element_print(stdout, ele);
        element_free(ele);
    }

    fprintf(stdout, "\nTamaño de la pila: %d\n", stack_size(s));
    
    stack_free(s);

    return 0;
}

