/* 
 * File:   p2_e0_a.c
 * Author: PABLO CUESTA, OLMAR ARRANZ
 *
 * Created on 25 de febrero de 2020, 10:33
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "stack_types.h"
#include "stack_fp.h"

int main(int argc, char** argv) {
    char string[] = "abc", *ele;
    Stack *s = NULL;
    int i;
    Status st = OK;

    if (!(s = stack_init(char_free, char_copy, char_print))) return 1;

    for (i = 0; i < strlen(string) && st == OK; i++) {
        st = stack_push(s, string + i);
    }

    stack_print(stdout, s);

    fprintf(stdout, "Tamaño de la pila: %ld\n", stack_size(s));

    while (stack_isEmpty(s) == FALSE){
        ele=stack_pop(s);
        printf("\nElemento extraído: ");
        char_print(stdout, ele);
        char_free(ele);
    }

    fprintf(stdout, "\nTamaño de la pila: %lu\n", stack_size(s));
    
    stack_free(s);

    return 0;
}

