/* 
 * File:   p2_e1.c
 * Author: PABLO CUESTA, OLMAR ARRANZ
 *
 * Created on 25 de febrero de 2020, 10:33
 * Versión: 2 marzo 2020, 18:58
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "stack_types.h"
#include "stack_fp.h"

#define MAX_WORD 100
#define MAX_STRING 10000

/**
 * @brief: Reverse the words of an input string to an output string.
 * The words in the input string are separated by a space character.
 * The strings may not overlap, and the destination string strout
 * must be large enough to receive the inverted expression.
 *
 * @param strout, Pointer to the output buffer
 * @param strin, Pointer to the input expression
 * @return The function returns OK or ERROR
 **/
Status reverseWords(char *strout, const char *strin);

int main(int argc, char** argv) {
    char *out = NULL;

    if(argc != 2) return (EXIT_FAILURE);

    out = (char*) malloc(sizeof (char)*MAX_STRING);

    if (!out) return 1;

    if (reverseWords(out, argv[1]) == ERROR) {
        string_free(out);
        return 2;
    }

    printf("\n%s\n", out);

    string_free(out);

    return 0;
}

Status reverseWords(char *strout, const char *strin) {
    Status st = OK;
    char *character = NULL;
    int i, j;
    Stack *s = NULL;

    if (!strout || !strin) return ERROR;

    if (!(s = stack_init(char_free, char_copy, char_print))) return ERROR;

    for (i = j = 0; strin[i] != '\0' && st == OK; i++) {
        
        if (strin[i] != ' ') {
            st = stack_push(s, strin + i);
        }
        else {
            while (stack_isEmpty(s) == FALSE) {
                character = stack_pop(s);
                strout[j] = *character;
                char_free(character);
                j++;
            }
            strout[j] = ' ';
            j++;
        }
    }

    while (stack_isEmpty(s) == FALSE) {
        character = stack_pop(s);
        strout[j] = *character;
        char_free(character);
        j++;
    }


    strout[j] = '\0';

    stack_free(s);
    return st;
}

