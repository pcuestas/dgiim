#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "tree.h"

#define max(a, b) ((a > b) ? (a) : (b))

typedef struct _BTNode {
    void *info;
    struct _BTNode *left;
    struct _BTNode *right;
} BTNode;

struct _BSTree {
    BTNode *root;
    destroy_element_function_type destroy_element;
    copy_element_function_type copy_element;
    print_element_function_type print_element;
    cmp_element_function_type cmp_element;
};

/*** DECLARACIÓN DE FUNCIONES PRIVADAS ***/
/* Create a BTNode*/
BTNode* bt_node_new();
/* Free a BTNode*/
void bt_node_free (BTNode *pn, destroy_element_function_type free_elem);

/*recursive function to free a tree*/
void tree_destroy_rec(BTNode *, destroy_element_function_type );

/*recursive function of tree_depth*/
int tree_depth_rec(BTNode *pn);

/*recursive function of tree_insert*/
Status tree_insert_rec (BTNode **ppn, const void *elem, 
    copy_element_function_type ele_copy, cmp_element_function_type ele_cmp,
    destroy_element_function_type free_elem);

/*rec. functions of pre, post, and in-order*/
int tree_preOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print);
int tree_inOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print);
int tree_postOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print);


/*** PRIMITIVAS PRIVADAS DE BT-NODOS ***/
BTNode * bt_node_new(){
    BTNode* pn = NULL;

    pn = (BTNode*)malloc(sizeof(BTNode));

    if (!pn) {
        fprintf (stderr,"%s\n", strerror (errno));
        return NULL;
    }
    pn->left = pn->right = NULL;
    pn->info = NULL;
    return pn;
}
void bt_node_free (BTNode *pn, destroy_element_function_type free_elem){
    if (!pn) return;
    free_elem(pn->info);
    free(pn);
}
/*** CREACIÓN Y LIBERACIÓN DE UN ÁRBOL ***/
/*Inicializa un árbol vacío.*/
BSTree* tree_init(destroy_element_function_type f1, copy_element_function_type f2,
print_element_function_type f3, cmp_element_function_type f4){
    BSTree* tree = malloc (sizeof(BSTree));

    if (!tree) {
        fprintf (stderr,"%s\n", strerror (errno));
        return NULL;
    }
    tree->root = NULL;
    tree->destroy_element=f1;
    tree->copy_element=f2;
    tree->print_element=f3;
    tree->cmp_element=f4;
    return tree;
}
/*Indica si el árbol está o no vacio*/
Bool tree_isEmpty( const BSTree *tree){
    if(!tree)
        return TRUE;
    if(tree->root == NULL)
        return TRUE;
    else 
        return FALSE;
}

/*Libera la memoria utilizada por un árbol.*/
void tree_destroy (BSTree *tree) {
    if(!tree)
        return ;
    tree_destroy_rec(tree->root, tree->destroy_element);
    
    free(tree);
}

void tree_destroy_rec(BTNode *pn, destroy_element_function_type func){
    if(!pn) /*base case*/
        return ;
    tree_destroy_rec(pn->left, func);
    tree_destroy_rec(pn->right, func);
    bt_node_free(pn, func);
}


/*Indica la profundidad del árbol. Un árbol vacio profundidad -1*/
int tree_depth (const BSTree *tree){
    if(!tree){  /*tree does not exist*/
        fprintf (stderr,"%s\n", strerror (errno));
        return -1;
    }
    return tree_depth_rec(tree->root);
}

int tree_depth_rec(BTNode *pn){
    int dleft, dright;

    /* base case, a tree with no nodes 
     * (a tree with only one node has depth 0)*/
    if(!pn)
        return -1; 

    dleft = tree_depth_rec(pn->left);
    dright = tree_depth_rec(pn->right);
    
    return (max(dleft, dright) + 1);
}

/*** INSERCIÓN ***/
/*Inserta un elemento en un árbol binario de búsqueda.*/
Status tree_insert (BSTree *tree, const void *elem){
    if(!tree || !elem){
        fprintf (stderr,"%s\n", strerror (errno));
        return ERROR;
    }
    return tree_insert_rec(&(tree->root), elem, tree->copy_element, 
                            tree->cmp_element, tree->destroy_element);
}

Status tree_insert_rec (BTNode **ppn, const void *elem, 
copy_element_function_type ele_copy, cmp_element_function_type ele_cmp,
        destroy_element_function_type free_elem){
    int cmp;

    /*base case*/
    if(!(*ppn)){
        /*create a new node*/
        if(!((*ppn) = bt_node_new()))
            return ERROR;
        if(!((*ppn)->info = ele_copy(elem))){
            bt_node_free(*ppn, free_elem);
            return ERROR;
        }
        return OK;
    }
    
    cmp = ele_cmp(elem, (*ppn)->info);

    if(cmp > 0)
        return tree_insert_rec(&((*ppn)->right), elem, ele_copy, ele_cmp, free_elem);
    else if(cmp < 0)
        return tree_insert_rec(&((*ppn)->left), elem, ele_copy, ele_cmp, free_elem);
    else 
        return OK; /*element alredy in the tree*/
}

/*** RECORRIDOS ***/
/*Recorre un árbol en orden previo.*/
int tree_preOrder (FILE *f, const BSTree *tree){
    if(!tree || !f){
        fprintf (stderr,"%s\n", strerror (errno));
        return -1;        
    }

    return tree_preOrder_rec(f, tree->root, tree->print_element);
}
int tree_preOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print){
    int check, count = 0;
    
    /*base case*/
    if(!pn)
        return 0;

    /*print parent node: */
    if((check = ele_print(f, pn->info)) < 0)
        return -1;
    count += check;

    /*print left node: */
    if((check = tree_preOrder_rec(f, pn->left, ele_print)) < 0)
        return -1;
    count += check;

    /*print right node: */
    if((check = tree_preOrder_rec(f, pn->right, ele_print)) < 0)
        return -1;
    count += check;

    return count;
}

/*Recorre un árbol en orden medio.*/
int tree_inOrder (FILE *f, const BSTree *tree){
    if(!tree || !f){
        fprintf (stderr,"%s\n", strerror (errno));
        return -1;        
    }

    return tree_inOrder_rec(f, tree->root, tree->print_element);
}
int tree_inOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print){
    int check, count = 0;
    
    /*base case*/
    if(!pn)
        return 0;

    /*print left tree: */
    if((check = tree_inOrder_rec(f, pn->left, ele_print)) < 0)
        return -1;
    count += check;

    /*print parent node: */
    if((check = ele_print(f, pn->info)) < 0)
        return -1;
    count += check;

    /*print right tree: */
    if((check = tree_inOrder_rec(f, pn->right, ele_print)) < 0)
        return -1;
    count += check;

    return count;
}
/*Recorre un árbol en orden posterior.*/
int tree_postOrder (FILE *f, const BSTree *tree){
    if(!tree || !f){
        fprintf (stderr,"%s\n", strerror (errno));
        return -1;        
    }

    return tree_postOrder_rec(f, tree->root, tree->print_element);
}
int tree_postOrder_rec(FILE *f, BTNode *pn, print_element_function_type ele_print){
    int check, count = 0;
    
    /*base case*/
    if(!pn)
        return 0;

    /*print left tree: */
    if((check = tree_postOrder_rec(f, pn->left, ele_print)) < 0)
        return -1;
    count += check;

    /*print right tree: */
    if((check = tree_postOrder_rec(f, pn->right, ele_print)) < 0)
        return -1;
    count += check;

    /*print parent node: */
    if((check = ele_print(f, pn->info)) < 0)
        return -1;
    count += check;

    return count;
}
