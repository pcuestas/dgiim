/*
 * File:   p4_e3_b.c
 * Author: pablo
 *
 * Created on 29 de abril de 2020, 9:42
 */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

#include "list.h"
#include "tree.h"
#include "types.h"


#define MAX_ID 1000

/**
 * @brief This functión insert n random integers between 0 and MAX_ID into
 * an ordered list pl[0]. And the same numbers into an unordered list pl[1]
 * 
 * This functions modifies the list input parameter.
 *
 * @param n, Length of the list
 * @param pl[], Array of 2 lists
 * @return This function returns OK or ERROR.
 **/
Status listRandomAndOrdered(int n, List *pl[]);

void *int_copy(const void *i);

int int_print(FILE *f, const void *i);

int int_cmp(const void *i, const void *j);

int clean_main(List *pl[], BSTree *pt[], Status error);

int main(int argc, char** argv) {
    List *pl[2] = {NULL, NULL};
    Status st = OK;
    BSTree *pt[2] = {NULL, NULL};
    int n, i, *element = NULL;

    if (argc != 2) {
        fprintf(stderr, "This main requires one argument, an integer(size of the initial lists)\n");
        return clean_main(pl, pt, EXIT_FAILURE);
    }

    n = atoi(argv[1]);

    for (i = 0; i < 2; i++) {
        if (!(pl[i] = list_new(free, int_copy, int_print, int_cmp)))
            return clean_main(pl, pt, EXIT_FAILURE);
        if (!(pt[i] = tree_init(free, int_copy, int_print, int_cmp)))
            return clean_main(pl, pt, EXIT_FAILURE);    
    }
    
    if(listRandomAndOrdered(n, pl) == ERROR)
        return clean_main(pl, pt, EXIT_FAILURE);
    
    for (i = 0; i < 2 && st == OK; i++) {
        printf("Printing list %d ...\n", i + 1);
        list_print(stdout, pl[i]);
        
        while (list_isEmpty(pl[i]) == FALSE && st == OK){
            element = (int*)list_popFront(pl[i]);
            st = tree_insert(pt[i], element);
            free(element);
            element = NULL;
        }
        
        if(st == OK){
            printf("\n\nTree depth: %d", tree_depth(pt[i]));
            
            printf("\n\nTree postOrder ...\n");
            tree_postOrder(stdout, pt[i]);
            
            printf("\n\nTree preOrder ...\n");
            tree_preOrder(stdout, pt[i]);
            
            printf("\n\nTree inOrder ...\n");
            tree_inOrder(stdout, pt[i]);
            
            printf("\n\n");
        }
    }
    
    if(st==ERROR)
        return clean_main(pl, pt, EXIT_FAILURE);

    return clean_main(pl, pt, (EXIT_SUCCESS));
}


Status listRandomAndOrdered(int n, List *pl[]) {
    int i, x;
    Status st = OK;

    if (!pl) return ERROR;

    for (i = 0; i < n && st == OK; i++) {
        x = rand() % MAX_ID;
        st = list_pushOrder(pl[0], &x, 1);
        if (st == OK)
            st = list_pushFront(pl[1], &x);
    }

    if (st == ERROR) {
        fprintf(stderr, "%s\n", strerror(errno));
        return ERROR;
    }

    return OK;
}

int clean_main(List *pl[], BSTree *pt[], Status error) {
    int i;
    
    for(i=0;i<2;i++){
        list_free(pl[i]);
        tree_destroy(pt[i]);
    }

    return error;
}

void *int_copy(const void *i) {
    int *j = NULL;

    if (!i) return NULL;

    if (!(j = (int*) malloc(sizeof (int))))return NULL;

    *j = *(int*) i;

    return j;
}

int int_cmp(const void *i, const void *j) {
    if (!i || !j) return 0;

    return ((*(int*) i)-(*(int*) j));
}

int int_print(FILE *f, const void *i) {
    if (!i)return -1;

    return fprintf(f, "%d ", *(int*) i);
}
