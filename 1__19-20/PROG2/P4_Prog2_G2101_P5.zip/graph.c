/* 
 * File:   graph.c
 * Author: Pablo Cuesta, Olmar Arranz
 * 
 * Created on 11 de febrero de 2020, 10:18
 * Primera versión: 11 febrero 2020, 18:48
 */

#include "graph.h"

#define MAX_NODES 1064
#define MAX_LINE 100

struct _Graph {
    Node *nodes[MAX_NODES]; /*!<Array with the graph nodes */
    Bool connections[MAX_NODES][MAX_NODES]; /*!<Adjacency matrix */
    int num_nodes; /*!<Total number of nodes in te graph */
    int num_edges; /*!<Total number of connection in the graph */
};

Graph * graph_init() {
    Graph *g = NULL;
    int i, j;

    if (!(g = (Graph*) malloc(sizeof (Graph))))
        return NULL;

    g->num_nodes = 0;
    g->num_edges = 0;

    for (i = 0; i < MAX_NODES; i++) {
        g->nodes[i] = NULL;
        for (j = 0; j < MAX_NODES; j++) {
            g->connections[i][j] = 0;
        }
    }

    return g;
}

void graph_free(Graph *g) {
    int i;

    if (!g) return;

    for (i = 0; i < MAX_NODES; i++)
        free(g->nodes[i]);

    free(g);
}

Status graph_insertNode(Graph *g, const Node *n) {
    if (!g || !n)
        return ERROR;

    if(find_node_index(g, node_getId(n)) != -1)
        return graph_setNode(g, n); /*it is alredy in the graph
                                     * so it gets updated
                                     */
    /*check if the copy has been succesfully completed:*/
    if (!(g->nodes[g->num_nodes] = node_copy(n)))
        return  ERROR;
    
    /*if it has happened correctly, 
     * add 1 to the number of nodes*/
    
    (g->num_nodes)++;

    return OK;
}


Status graph_insertEdge(Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;

    if (!g || nId2 == nId1) return ERROR;

    if ((pos1 = find_node_index(g, nId1)) == -1) return ERROR;
    if ((pos2 = find_node_index(g, nId2)) == -1) return ERROR;

    if (graph_areConnected(g, nId1, nId2) == FALSE) {
        g->connections[pos1][pos2] = TRUE;
        node_setNConnect(g->nodes[pos1], node_getConnect(g->nodes[pos1]) + 1);
		(g->num_edges)++;
    }

    return OK;
}

Node *graph_getNode(const Graph *g, long nId) {
    int index;
    Node *aux = NULL;

    if (!g) return NULL;
    if ((index = find_node_index(g, nId)) == -1) return NULL;

    if(!(aux = node_copy(g->nodes[index]))) return NULL;
    
    return aux;
}

Status graph_setNode(Graph *g, const Node *n) {
    int index;

    if (!g || !n) return ERROR;

    if ((index = find_node_index(g, node_getId(n))) == -1) return ERROR;

    node_setName(g->nodes[index], node_getName((Node*) n));
    node_setLabel(g->nodes[index], node_getLabel(n));
    node_setNConnect(g->nodes[index], node_getConnect(n));
    node_setPredecessorId(g->nodes[index], node_getPredecessorId(n));

    return OK;
}

long * graph_getNodesId(const Graph *g) {
    long *Ids, i;

    if (!g)return NULL;

    if (!(Ids = (long*) malloc((g->num_nodes) * sizeof (long)))) return NULL;

    for (i = 0; i < g->num_nodes; i++)
        Ids[i] = node_getId(g->nodes[i]);

    return Ids;
}

int graph_getNumberOfNodes(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_nodes;
}

int graph_getNumberOfEdges(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_edges;
}

Bool graph_areConnected(const Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;

    if (!g) return FALSE;

    if ((pos1 = find_node_index(g, nId1)) == -1) return FALSE;
    if ((pos2 = find_node_index(g, nId2)) == -1) return FALSE;

    return g->connections[pos1][pos2];
}

int graph_getNumberOfConnectionsFrom(const Graph *g, const long fromId) {
    int pos;

    if (!g) return -1;

    if ((pos = find_node_index(g, fromId)) == -1) return -1;

    return node_getConnect(g->nodes[pos]);
}

long* graph_getConnectionsFrom(const Graph *g, const long fromId) {
    long *Ids = NULL;
    int i, j, index, nconnections;

    /*check pointer*/
    if (!g) return NULL;

    /*check if node with that id is in the graph and get its index*/
    if ((index = find_node_index(g, fromId)) == -1) return NULL;

    nconnections = node_getConnect(g->nodes[index]);

    /*we allocate the memory for the array of ids*/
    if (!(Ids = (long*) calloc(nconnections, (sizeof (long))))) return NULL;

    /*for every node connected to g->nodes[index], we keep its id in Ids.*/
    for (i = j = 0; i < g->num_nodes; i++) {
        if (g->connections[index][i] == TRUE) {
            Ids[j] = node_getId(g->nodes[i]);
            j++;
        }

    }

    return Ids;
}

int graph_print(FILE *pf, const Graph * g) {
    int i, j, cha = 0;
    long *Ids;

    if (!pf || !g) {
        fprintf(stderr, "%s\n", strerror(errno));
        return -1;
    }


    for (i = 0; i < g->num_nodes; i++) {
        cha += node_print(pf, g->nodes[i]);

        /*get the array of ids of nodes connected to node with index i:*/
        if (!(Ids = graph_getConnectionsFrom(g, node_getId(g->nodes[i])))) {
            fprintf(stderr, "%s\n", strerror(errno));
            return -1;
        }

        /*print ids of all nodes connected to node with index i*/
        for (j = 0; j < node_getConnect(g->nodes[i]); j++) {
            cha += fprintf(pf, " %ld", Ids[j]);
        }

        free(Ids);
        fprintf(pf, "\n");
    }

    return cha;
}

Status graph_readFromFile(FILE *fin, Graph * g) {
    Node *n;
    int nnodes;
    char buff[MAX_LINE], name[NAME_L];
    int i;
    long id1, id2;
    int label;
    Status flag = OK;


    if (!fin || !g) return ERROR;

    if (!(n = node_init())) return ERROR;

    if (fgets(buff, MAX_LINE, fin) != NULL)
        if (sscanf(buff, "%d", &nnodes) != 1)return ERROR;

    for (i = 0; i < nnodes && flag == OK; i++) {

        if (fgets(buff, MAX_LINE, fin)) {

            if (sscanf(buff, "%ld %s %d", &id1, name, &label) == 3) {
                node_setId(n, id1);
                node_setLabel(n, label);
                node_setName(n, name);
                flag = graph_insertNode(g, n);
            } else flag = ERROR;

        } else flag = ERROR;
    }

    if (i < nnodes) flag = ERROR;

    while (flag == OK && (fgets(buff, MAX_LINE, fin) != NULL)) {
        if (sscanf(buff, "%ld %ld", &id1, &id2) == 2) {
            flag = graph_insertEdge(g, id1, id2);
        } else flag = ERROR;
    }

    node_free(n);

    if (!feof(fin))
        flag = ERROR;

    return flag;

}



/*******private functions****************/

/* It returns the index of the node with id nId1*/

int find_node_index(const Graph * g, int nId1) {
    int i;

    if (!g) return -1;

    for (i = 0; i < g->num_nodes; i++) {
        if (node_getId(g->nodes[i]) == nId1) return i;
    }

    /* ID not found*/
    return -1;
}

/* It returns an array with the indices of the nodes connected to the node
*  whose index is index
* It also allocates memory for the array.
**/

int* graph_getConnectionsIndex(const Graph *g, int index) {
    int *array = NULL, i, j = 0, size;

    if (!g) return NULL;

    if (index < 0 || index > g->num_nodes) return NULL;

    /* get memory for the array*/
    size = node_getConnect(g->nodes[index]);
    array = (int *) malloc(sizeof (int) * size);

    if (!array) {
        /* print error message*/
        fprintf(stderr, "%s\n", strerror(errno));
        return NULL;
    }

    /*assign values to the array with the indices of the connected nodes*/
    for (i = 0; i < g->num_nodes; i++) {
        if (g->connections[index][i] == TRUE) {
            array[j] = i;
            j++;
        }
    }

    return array;
}
