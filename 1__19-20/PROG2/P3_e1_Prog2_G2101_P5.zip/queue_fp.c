/* 
 * File:   queue_fp.c
 * Author: Pablo Cuesta
 * 
 * Created on 17 de marzo de 2020, 11:31
 */

#include "queue_fp.h"

#define MAXQUEUE 1024


struct _Queue {
    int front;
    int rear;
    destroy_element_function_type free_element_function;
    copy_element_function_type copy_element_function;
    print_element_function_type print_element_function;
    void* items [MAXQUEUE];
};

/********** funciones privadas: ********/

Bool queue_isFull(Queue *q) {
    if (!q) return TRUE;

    if (q->front == (q->rear + 1) % MAXQUEUE) return TRUE;

    return FALSE;
}


/******* funciones públicas: ********/

Queue* queue_init(destroy_element_function_type f1,
        copy_element_function_type f2, print_element_function_type f3) {
    Queue *q = NULL;
    int i;

    if (!(q = (Queue*) malloc(sizeof (Queue)))) return NULL;

    for (i = 0; i < MAXQUEUE; i++)
        q->items[i] = NULL;
    q->rear = 0;
    q->front = 0;
    q->free_element_function = f1;
    q->copy_element_function = f2;
    q->print_element_function = f3;

    return q;
}


void queue_free(Queue *q) {
    int i;
    if (!q) return;

    if (queue_isEmpty(q)) {
        free(q);
        return;
    }

    for (i = q->front; i != q->rear; i = (i + 1) % MAXQUEUE)
        q->free_element_function(q->items[i]);

    free(q);
}


Bool queue_isEmpty(const Queue *q) {
    if (!q)return TRUE;

    if (q->front == q->rear)
        return TRUE;
    else
        return FALSE;
}


Status queue_insert(Queue *q, const void* pElem) {

    if (!q || !pElem) return ERROR;

    /* we have to check whether the queue is full */
    if (queue_isFull(q) == TRUE) return ERROR;

    if (!(q->items[q->rear] = q->copy_element_function(pElem))) return ERROR;

    q->rear = (q->rear + 1) % MAXQUEUE;

    return OK;
}


void * queue_extract(Queue *q) {
    void *ele = NULL;

    if (!q) return NULL;

    if (queue_isEmpty(q)) return NULL;

    ele = q->items[q->front];

    q->items[q->front] = NULL;

    q->front = (q->front + 1) % MAXQUEUE;

    return ele;
}


int queue_size(const Queue *q) {
    int size;

    if (!q) return -1;

    size = (q->rear - q->front) % MAXQUEUE;


    return size >= 0 ? size : (MAXQUEUE + size);
}


int queue_print(FILE *pf, const Queue *q) {
    int count, i;

    if (!q || !pf) return -1;

    for (i = count = 0; i < queue_size(q); i++) {
        count += q->print_element_function(pf, q->items[(q->front + i) % MAXQUEUE]);
    }
    
    return count;
}


