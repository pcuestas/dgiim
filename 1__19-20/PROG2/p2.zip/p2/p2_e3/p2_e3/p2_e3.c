/* 
 * File:   p2_e3.c
 * Author: e422974
 *
 * Created on 10 de marzo de 2020, 10:58
 */

#define MAX_WORD 100
#define MAX_STRING 10000

#include <stdio.h>
#include <stdlib.h>

#include "stack.h"
#include "types.h"
#include "element.h"

Status reverseWords(char *strout, const char *strin);

int main(int argc, char** argv) {
    char *out = NULL;
    char str[]="HELLO WORLD";

    out = (char*) malloc(sizeof (char)*MAX_STRING);

    if (!out) return 1;

    if (reverseWords(out, str) == ERROR) {
        free(out);
        return 2;
    }

    printf("\n%s\n", out);

    free(out);

    return 0;
}

Status reverseWords(char *strout, const char *strin) {
    Status st = OK;
    Element *ele = NULL;
    int i, j;
    Stack *s = NULL;

    if (!strout || !strin) return ERROR;

    if (!(s = stack_init())) return ERROR;

    for (i = j = 0; i <= strlen(strin) && st == OK; i++) {

        if (strin[i] != ' ' && i != strlen(strin)) {
            if (!(ele = element_init())) st = ERROR;
            st = element_setInfo(ele, (void*)(strin + i));
            st = stack_push(s, ele);
            element_free(ele);
        } else {
            while (stack_isEmpty(s) == FALSE && st == OK) {

                if ((ele = stack_pop(s)) == NULL) {
                    st = ERROR;
                }
                else {
                    strout[j] = *(char*) element_getInfo(ele);
                    element_free(ele);
                    j++;
                }
            }
            strout[j] = ' ';
            j++;
        }
    }
    
    strout[j - 1] = 0;

    stack_free(s);
    
    return st;

}

