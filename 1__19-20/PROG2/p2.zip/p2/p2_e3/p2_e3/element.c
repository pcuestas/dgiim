
#include "element.h"

struct _Element {
    char *a;
};

Element *element_init() {
    Element *ele = NULL;

    if (!(ele = (Element*) malloc(sizeof (Element)))) return NULL;

    ele->a = NULL;

    return ele;
}

void element_free(Element *e) {
    if (!e) return;

    free(e->a);

    e->a = NULL;

    free(e);
}

Status element_setInfo(Element *e, void *ch) {
    if (!e || !ch) return ERROR;
	
    if(!(e->a)){
    	if (!(e->a = (char*) malloc(sizeof (char)))) 
            return ERROR;
    }

    *(e->a) = *(char*) ch;

    return OK;
}

void * element_getInfo(Element *e) {
    if (!e)
        return NULL;
    else
        return e->a;
}

Element * element_copy(const Element *e) {
    Element *new = NULL;

    if (!e || !(e->a))return NULL;

    if (!(new = element_init()))return NULL;

    if (!(new->a = (char*) malloc(sizeof (char)))) return NULL;

    *(new->a) = *(char*) e->a;

    return new;

}

Bool element_equals(const Element *e1, const Element *e2) {
    if (!e1 || !e2 || !(e1->a) || !(e2->a)) return FALSE;

    if (*(e1->a) == *(e2->a))
        return TRUE;
    else
        return FALSE;
}

int element_print(FILE *fp, const Element *e) {
    int count = 0;

    if (!e || !e->a)return -1;

    count = fprintf(fp, "%c", *(e->a));

    return count;
}
