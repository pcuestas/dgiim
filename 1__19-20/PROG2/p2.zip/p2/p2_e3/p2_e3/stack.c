

#include "stack.h"
#include "element.h"

# define MAXSTACK 1024
struct _Stack {
    int top;
    Element * item[MAXSTACK];
};

/**
 * the top is the same as the size of the stack 
 * (in number of elements) just like the size of a string
 * it 'points' to the next element to be inserted
 **/

Stack * stack_init (){
    Stack *s = NULL;
    int i;

    if(!(s=(Stack*)malloc (sizeof(Stack)))) return NULL;

    s->top = 0;

    for(i=0; i<MAXSTACK; i++)
        s->item[i] = NULL;

    return s;
}

void stack_free(Stack *s){
    int i;

    if(!s) return;

    for(i=0; i < MAXSTACK; i++){
        element_free(s->item[i]);
    }
    
    free(s);
}

Status stack_push(Stack *s, const Element *ele){
    Element *aux;
    
    if(!s || !ele) return ERROR;

    if(stack_isFull(s) == TRUE) return ERROR;

    if(!(aux = element_copy(ele))) return ERROR;

    s->item[s->top] = aux;

    (s->top)++;

    return OK;
}

Element * stack_pop(Stack *s){
    Element *ele=NULL;

    /*the following funtion alredy checks if the pointer is null*/
    if(stack_isEmpty(s) == TRUE)
        return NULL;

    ele = s->item[s->top-1];

    s->item[s->top-1] = NULL;

    (s->top)--;

    return ele;
}

/* returns the pointer to the top, it does NOT allocate memory */
Element * stack_top(const Stack *s){
    
    /*the following funtion alredy checks if the pointer is null*/
    if(stack_isEmpty(s) == TRUE)
        return NULL;
    else
        return s->item[s->top];

}

Bool stack_isEmpty(const Stack *s){
    if(!s) return FALSE;

    if((s->top) == 0) 
        return TRUE;
    else 
        return FALSE;
}

Bool stack_isFull(const Stack *s){
    if(!s) return FALSE;

    if((s->top) == MAXSTACK) 
        return TRUE;
    else 
        return FALSE;
}

int stack_print(FILE *fp, const Stack *s){
    int i, count, check;

    if(!fp || !s) return -1;

    for(i = count = 0; i < (s->top) && check !=- 1; i++){
        check = element_print(fp, s->item[i]);
        count = count + check; 
    }

    if(check == -1)
        return -1;
    else
        return count; 
}