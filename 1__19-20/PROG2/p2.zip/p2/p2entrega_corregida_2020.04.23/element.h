/*
* File: element.h
* Author: Profesores de PROG2
*/
#ifndef ELEMENT_H
#define ELEMENT_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"


typedef struct _Element Element;

Element * element_init();

void element_free(Element *e);

Status element_setInfo(Element *, void *);

/*does NOT allocate memory*/
void * element_getInfo(Element *);

Element * element_copy(const Element *e);

Bool element_equals(const Element *e1, const Element *e2);

int element_print(FILE *fp, const Element *e);

#endif /* ELESTACK_H */