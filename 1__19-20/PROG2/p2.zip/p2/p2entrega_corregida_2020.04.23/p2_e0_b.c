/* 
 * File:   p2_e0_b.c
 * Author: PABLO CUESTA, OLMAR ARRANZ
 *
 * Created on 25 de febrero de 2020, 10:33
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "stack_types.h"
#include "stack_fp.h"
#include "node.h"

int main(int argc, char** argv) {
    char *ele=NULL, name[NAME_L];
    Stack *ss = NULL, *sn = NULL;
    int id;
    Node *node=NULL;
    
    if (!(ss = stack_init(string_free, string_copy, string_print))) return 1;
    if (!(sn = stack_init(node_free, node_copy, node_print))){
        stack_free(ss);
        return 2;
    }
    
    if(!(node=node_init())){
        stack_free(sn);
    	stack_free(ss);
        return 3;
    }
    
    strncpy(name, "first", NAME_L);
    id=111;
    node_setName(node, name);
    node_setId(node, id);
    
    if(stack_push(sn, node)==ERROR){
        node_free(node);
        stack_free(sn);
        stack_free(ss);
        return 4;
    }
    
    if(stack_push(ss, node_getName(node))==ERROR){
        node_free(node);
        stack_free(sn);
        stack_free(ss);
        return 5;
    }
    
    strncpy(name, "second", NAME_L);
    id=222;
    node_setName(node, name);
    node_setId(node, id);
    
    
    if(stack_push(sn, node)==ERROR){
        node_free(node);
        stack_free(sn);
        stack_free(ss);
        return 6;
    }
    
    if(stack_push(ss, node_getName(node))==ERROR){
        node_free(node);
        stack_free(sn);
        stack_free(ss);
        return 7;
    }
    node_free(node);
    
    printf("Node stack print:\n");
    stack_print(stdout, sn);
    
    printf("\nString stack print:\n");
    stack_print(stdout, ss);
    
    printf("\nPopping nodes: \n");
    while(stack_isEmpty(sn)==FALSE){
        node=stack_pop(sn);        
        node_print(stdout, node);
        printf("\n");
        node_free(node);
    }
    
    printf("\nPopping node names: \n");
    while(stack_isEmpty(ss)==FALSE){
        ele=stack_pop(ss);
        string_print(stdout, ele);
        printf("\n");
        string_free(ele);
    }
    
    printf("\n");
    stack_free(sn);
    stack_free(ss);

    return 0;
}

