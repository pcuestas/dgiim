/* 
 * File:   p2_e1.c
 * Author: PABLO CUESTA, OLMAR ARRANZ
 *
 * Created on 3 de marzo de 2020, 10:20
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "types.h"
#include "stack_types.h"
#include "stack_fp.h"

#define OPERATORS { '+', '-', '*', '/', '%', '^' };
#define WORD_L 1000

Bool isOperator(const char *c);

int prec(const char *c);


/**
 * @brief: Get the postfix expression of an infix expression.
 * The infix and postfix strings may not overlap and
 * the destination postfix string must be
 * large enough to receive the infix expression
 * (to be checked before calling this function).
 * @param in Pointer to the infix expression
 * @param suf Pointer to the suffix expression
 * @return The function returns OK on success or ERROR
 * when any of its parametrs is NULL
 **/
Status infix2postfix(char *suf, const char *in);

int main(int argc, char** argv) {
    char *sufix = NULL;

    sufix = (char*) malloc(sizeof (char)*WORD_L);
    if (!sufix) return 1;

    if (infix2postfix(sufix, argv[1]) == ERROR) {
        string_free(sufix);
        return 2;
    }

    printf("\n%s\n", sufix);

    string_free(sufix);


    return 0;
}

Status infix2postfix(char *suf, const char *in) {
    Status st = OK;
    Stack *s = NULL;
    char *ele;
    int i;
    int j;


    if (!suf || !in) return ERROR;

    if (!(s = stack_init(char_free, char_copy, char_print))) return ERROR;

    for (i = j = 0; in[i] != '\0' && st == OK; i++) {

        if (isOperator(in + i) == TRUE) {
            while (stack_isEmpty(s) == FALSE && prec(stack_top(s)) >= prec(in + i)) {
                ele = stack_pop(s);
                suf [j++] = *ele;
                char_free(ele);
                }            
            st = stack_push(s, in + i);
        } 
        else if (in[i] == '(') {
            st = stack_push(s, in + i);
        } 
        else if (in[i] == ')') {
            while (stack_isEmpty(s) == FALSE && *(char*) stack_top(s) != '(') {
                ele = stack_pop(s);
                suf [j++] = *ele;
                char_free(ele);
            }
            /* pop the open paranthesis*/
            ele = stack_pop(s);
            char_free(ele);
        } 
        else {
            if (in[i] != ' ') {
                suf[j] = in[i];
                j++;
            }
        }
    }
    
    if (st == OK) {
        while (stack_isEmpty(s) == FALSE){
            ele = stack_pop(s);
            suf [j++] = *ele;
            char_free(ele);
        }
    }
    
    suf[j] = '\0';

    stack_free(s);

    return st;
}

Bool isOperator(const char *c) {
    int size;
    int i;
    char oper[] = OPERATORS;

    if (!c) return FALSE;

    size = sizeof (oper) / sizeof (char);

    for (i = 0; i < size; i++)
        if (*c == oper[i])
            return TRUE;

    return FALSE;
}

int prec(const char *c) {
    if (!c)
        return 0;
    else if (*c == '+' || *c == '-')
        return 1;
    else if (*c == '*' || *c == '/')
        return 2;
    else if (*c == '%')
        return 3;
    else if (*c == '^')
        return 4;
    else
        return 0;
}