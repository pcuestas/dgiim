######Pablo Cuesta y Olmar Arranz. Grupo 2101, Pareja 5.

---

1. **Proporciona un script que incluya los comandos necesarios para compilar, enlazar y crear un ejecutable con el compilador gcc, indicando que acción se realiza en cada una de las sentencias del script. ATENCIÓN no se está pidiendo un fichero Makefile.**

Ejercicio 1:

Entramos con la terminal en el directorio donde tengamos los archivos necesarios:
Creamos los archivos .o a partir de los .c:
		gcc -c p1_e1.c
		gcc -c node.c
Enlazamos los ficheros (.o), para obtener el ejecutable:
		gcc -o p1_e1 p1_e1.o node.o
Obtenemos el fichero p1_e1 que podemos ejecutar: 
		./p1_e1 
   	(o, para comprobar si hay errores, con valgrind: )
		valgrind ./p1_e1

Ejercicio 2:

Entramos con la terminal en el directorio donde tengamos los archivos necesarios:
Creamos los archivos .o a partir de los .c:
		gcc -c p1_e2.c
		gcc -c graph.c
		gcc -c node.
Enlazamos los ficheros (.o), para obtener el ejecutable:
		gcc -o p1_e2 p1_e2.o node.o graph.c
Obtenemos el fichero p1_e2 que podemos ejecutar: 
		./p1_e2
		valgrind ./p1_e2

Ejercicio 3:

Entramos con la terminal en el directorio donde tengamos los archivos necesarios:
Creamos los archivos .o a partir de los .c:
		gcc -c p1_e3.c
		gcc -c graph.c
		gcc -c node.c
Enlazamos los ficheros (.o), para obtener el ejecutable:
		gcc -o p1_e3 p1_e3.o node.o graph.o
Obtenemos el fichero p1_e3 que podemos ejecutar, con el archivo del que queremos que lea el grafo como argumento de la función: 
		./p1_e3 name_of_file.txt
		valgrind ./p1_e3 name_of_file.txt

2. **Justifique brevemente si son correctas o no las siguientes implementaciones de las funciones y en el caso de que no lo sean justifique el porqué (suponed que el resto de las funciones se han declarado e implementado como en la práctica)**

   2.a)
   	int main() {
   		Node *n1;
   		n1 = (Node*) malloc(sizeof(Node));
   		if (!n1) return EXIT_FAILURE;
   		/* Set fields */
   		node_setId (n1, -1);
   		node_setName (n1, "");
   		node_setConnect (n1, 0);
   		node_free (n1);
   		return EXIT_SUCCESS;
   	}

Esta función es correcta, aunque no utiliza al función node_init(), a la que un usuario del TAD nodo tiene acceso, porque es una primitiva, y hace "manualmente" la inicialización del nodo.


   2.b)
   	// In the file node.h
   	Status node_init (Node *n);
   
   	// In the file node.c
   	Status node_init (Node *n) {
   		n = (Node *) malloc(sizeof(Node));
   		if (!n) return ERROR;
   		/* init fields */
   		node_setId (n, -1);
   		node_setName (n, "");
   		node_setConnect (n, 0);
   		node_setLabel (n, BLANCO);
   		return OK;
   	}
   	
   	// en main.c
   	int main() {
   		Node *n1;
   		if (node_ini (n1) == ERROR)
   		return EXIT_FAILURE;
   		node_free (n1);
   		return EXIT_SUCCESS;
   	}

No es correcta porque la función Status node_init(Node *n) al recibir como argumento un puntero a nodo, está recibiendo una copia del puntero (su dirección), y al modificar la copia, no se cambia el puntero mandado. Además, se perdería memoria porque dentro de la función se reserva memoria a la que fuera no se puede acceder.

   2.c)
   	// In the file node.h
   	Status node_init (Node **n);
   	// In the file node.c
   	Status node_init (Node **n) {
   		*n = (Node *) malloc(sizeof(Node));
   		if (*n == NULL) return NULL;
   		/* inicializa campos */
   		node_setId (*n, -1);
   		node_setName (*n, "");
   		node_setConnect (*n, 0);
   		return OK;
   	}
   	// In main.c
   	int main() {
   		Node *n1;
   		if (node_ini (&n1) == ERROR)
   		return EXIT_FAILURE;
   		node_free (n1);
   		return EXIT_SUCCESS;
   	}

De este código, el único error es que si no se puede reservar la memoria, se debe devolver ERROR, por ser la función de tipo Status, no un puntero (ya que pone 'return NULL'). En este caso, como se manda como argumento de la función la dirección de un puntero a nodo, no el puntero, sí se puede reservar memoria modificando el contenido del puntero a puntero a nodo (que es un puntero a nodo, del cual se tiene la dirección, no una copia). 

3. **¿Sería posible implementar la función de copia de nodos empleando el siguiente prototipo? ¿Por qué? STATUS node_copy (Node nDest, const Node nOrigin);**

RESPUESTA: no, ya que al estar pasando dos nodos (y no punteros a nodo), se crea una copia de estos que por mucho que se cambie, no va a modificar el nodo que se ha pasado a la función. Sin embargo, se podría utilizar el prototipo: *Status node_copy (Node *nDest, const Node *nOrigin); 

4. **¿Es imprescindible el puntero Node * en el prototipo de la función int node_ print (FILE * pf, const Node * n); o podría ser int node_print(FILE * pf, const Node p); ?**

**Si la respuesta es sí: ¿Por qué? Si la respuesta es no: ¿Por qué se utiliza, entonces?**

RESPUESTA: sí es imprescindible, ya que Node hace referencia a una estructura (struct _Node) de modo que la forma de pasar la información de ésta es pasando su puntero correspondiente. 

5. **¿Qué cambios habría que hacer en la función de copiar nodos si quisiéramos que recibiera un nodo como argumento donde hubiera que copiar la información? Es decir, ¿cómo se tendría que implementar si en lugar de Node* node_ copy(const Node* nOrigin), se hubiera definido como STATUS node_copy(const Node* nSource, Node* nDest)? ¿Lo siguiente sería válido: STATUS node_copy(const Node* nSource, Node * * nDest);?**

**Discute las diferencias.**

RESPUESTA: STATUS node_ copy(const Node* nSource, Node* nDest) no sería válido, porque al salir de la función, se pierde la información guardada en nDest, ya que al comenzar la función es una copia del puntero que se ha mandado como argumento, y entonces éste puntero que se ha mandado, con la intención de reservar memoria en él para luego copiar la información, no se puede modificar y queda sin cambiar. Sin embargo, STATUS node_copy(const Node* nSource, Node** nDest) sí que estaría bien ya que estamos enviando un puntero a puntero a nodo, de modo que podemos modificar su contenido, reservando memoria y guardando así la información al salir de la función de tipo Status.    ​

6. **¿Por qué las funciones privadas incluidas en el apéndice no deben ser funciones públicas? Justifica la respuesta.**

RESPUESTA: porque son útiles para la implementación de las funciones del TAD grafo, pero no queremos que sean parte de la interfaz que pueda utilizar un usuario del TAD. 

7. **Podría ser el tipo devuelto por la función node_copy diferente a void *. Justifica la respuesta.**

RESPUESTA: sí, podría ser de tipo (Node *), ya que el puntero que se está devolviendo corresponde aun nuevo nodo que se ha creado igual que el pasado a la función como argumento.
   ​	
