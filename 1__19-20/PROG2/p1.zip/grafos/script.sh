
#compilamos los ficheros .c:
gcc -c p1_e1.c
gcc -c p1_e2.c
gcc -c p1_e3.c

gcc -c node.c
gcc -c graph.c

#enlazamos todos los ficheros .o:
gcc -o p1_e1 p1_e1.o node.o
gcc -o p1_e2 p1_e2.o node.o graph.c
gcc -o p1_e3 p1_e3.o node.o graph.c


#eliminamos los ficheros .o:
rm *.o


#Para ejecutar los programas, tendríamos que escribir en la teminal después:
#          ./p1_e1
#          ./p1_e2
#           en el ejercicio 3, el nombre del fichero del que se quiere leer el grafo se debe poner de la siguiente forma:
#          ./p1_e3 name_of_file.txt  


		

