/* 
 * File:   main.c
 * 
 * Description: exercise 1 from practice 2
 * 
 * Author: Pablo Cuesta, Olmar Arranz
 *
 * Created on 18 de febrero de 2020, 10:56
 * 
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "graph.h"
#include "node.h"

int main(int argc, char** argv) {
    Graph *g;
    FILE *f;
    
    if(!(f=fopen(argv[1], "r"))) return 1;
    
    g = graph_init();
    if (!g) return 2;
            
    if (graph_readFromFile(f, g)==ERROR){
        graph_free(g);
        return 3;
    }
    
    fclose(f);
    
    graph_print(stdout, g); 
    
    graph_free(g);
    
    return (EXIT_SUCCESS);
}
