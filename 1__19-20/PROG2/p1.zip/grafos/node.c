/* 
 * File:   node.c
 * 
 * Description: Implementation of the functions for the ADT "node"
 * 
 * Author: Pablo Cuesta, Olmar Arranz
 * 
 * Created on 4 de febrero de 2020, 10:30
 *  
 * Primera versión: 4 febrero 2020, 17:24
 * Segunda versión: 6 febrero 2020, 18:34
 * Segunda versión: 7 febrero 2020, 18:21
 * Tercera versión: 8 febrero 2020, 23:55
 * 
 * Modificaciones necesarias:
 *          - función node_free???
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "node.h"

#define NAME_L 64

struct _Node {
    char name[NAME_L]; /*!<Node name */
    long id; /*!<Node id */
    int nConnect; /*!<Node number of connections */
    Label label; /*!<Node state */
};

Node * node_init() {
    Node *n = NULL;

    /* reservo memoria*/
    if (!(n = (Node *) malloc(sizeof (Node))))
        return NULL;

    /* asigno valores   */     
    strncpy(n->name, "", NAME_L); 
    n->id = -1;
    n->nConnect = 0;
    n->label = WHITE;

    return n;
}

void node_free(void * n) {
    if (n)
        free((Node *) n);
}

long node_getId(const Node * n) {
    if (!n)
        return -1;

    return n->id;
}

const char* node_getName(Node * n) {
    if (!n)
        return NULL;

    return n->name;
}

int node_getConnect(const Node * n) {
    if (!n)
        return -1;

    return n->nConnect;
}

Label node_getLabel(const Node*n) {
    if (!n)
        return -1;

    return n->label;
}

Status node_setLabel(Node *n, Label l) {
    if (!n)
        return ERROR;

    n->label = l;

    return OK;
}

Status node_setId(Node * n, const long id) {
    if (!n)
        return ERROR;

    n->id = id;

    return OK;
}

Status node_setName(Node *n, const char *name) {
    if (!n)
        return ERROR;
    if (!name)
        return ERROR;

    strncpy(n->name, name, NAME_L);

    return OK;
}

Status node_setNConnect(Node *n, const int cn) {
    if (!n || cn < 0)
        return ERROR;

    n->nConnect = cn;

    return OK;
}

int node_cmp(const void *n1, const void *n2) {
    /* we don't have the possibility to check pointers
     * beacause all integer values have a meaning in this case
     */

    Node *s1, *s2;

    s1 = (Node*) n1;
    s2 = (Node*) n2;

    if ((s1->id != s2->id))
        return ((s1->id) - (s2->id));
    else
        return (strcmp(s1->name, s2->name));
}

void * node_copy(const void *src) {
    Node *trg, *aux = NULL;

    /*check pointers*/
    if (!src)
        return NULL;

    aux = (Node*) src;

    /*allocate memory for the new node*/
    if (!(trg = node_init()))
        return NULL;

    /*copy everything from node src (using aux, which has same value) to new node */
    strncpy(trg->name, aux->name, NAME_L);
    trg->id = aux->id;
    trg->nConnect = aux->nConnect;
    trg->label = aux->label;

    return trg;
}

int node_print(FILE *pf, const void *n) {
    Node *aux = NULL;
    int characters;

    /*check pointers*/
    if (!pf || !n)
        return -1;

    aux = (Node*) n;

    characters = fprintf(pf, "[%s, %ld, ", aux->name, aux->id);
    characters += fprintf(pf, "%d, %hd]", aux->nConnect, aux->label);

    return characters;
}
