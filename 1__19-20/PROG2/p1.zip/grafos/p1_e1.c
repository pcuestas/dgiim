/* 
 * File:   main.c
 * 
 * Description: exercise 1 from practice 1
 * 
 * Author: Pablo Cuesta, Olmar Arranz
 *
 * Created on 4 de febrero de 2020, 10:22
 * 
 * Primera versión: 4 febrero 2020, 17:24
 * Segunda versión: 6 febrero 2020, 18:34 
 * Tercera versión: 8 febrero 2020, 23:55
 * 
 */

#include <stdio.h>
#include <stdlib.h>

#include "node.h"

int main(int argc, char** argv) {
    Node *n = NULL;
    Node *s = NULL;
    long id1;
    const char *name2;

    /*initialize both nodes and check for errors*/
    if (!(n = node_init()))
        return 1;
    if (!(s = node_init())){
        free (n);
        return 1;
    }
    /* as we make the changes in name and id, we check if there is an error
     * while executing the functions (0 is ERROR)
     */
    if (node_setName(n, "first") == 0) return 1;
    if (node_setName(s, "second") == 0) return 1;
    if (node_setId(n, 111) == 0) return 1;
    if (node_setId(s, 222) == 0) return 1;

    /*print content of both nodes in the display*/
    node_print(stdout, n);
    node_print(stdout, s);
    printf("\n");

    printf("¿Son iguales? ");

    if (!(node_cmp(n, s)))
        printf("Sí.\n");
    else
        printf("No.\n");

    /*check if there is an error during the execution of the functions:*/
    id1 = node_getId(n);
    name2 = node_getName(s);

    /*print the info that we got form the functions*/
    printf("Id del primer nodo: %ld\n", id1);
    printf("Nombre del segundo nodo: %s\n", name2);

    /*free s before asigning it a different address*/
    node_free(s);
    if (!(s = node_copy(n))){
        free(n);
        return 1;
    }
    
    node_print(stdout, n);
    node_print(stdout, s);
    printf("\n");

    /*we again check if they are the same node*/
    printf("¿Son iguales? ");

    if (!(node_cmp(n, s)))
        printf("Sí.\n");
    else
        printf("No.\n");

    node_free(n);
    node_free(s);

    return (EXIT_SUCCESS);
}
