/* 
 * File:   p3_e3_c.c
 * Author: Pablo Cuesta, Olmar Arranz
 *
 * Created on 30 de marzo de 2020, 18:08
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "graph.h"
#include "node.h"
#include "stack_fp.h"

#define MAXSTRING 65536

/**
* @brief This function implements the DFS algorithm starting
* from the node with id ini_id
* @param pg, Graph
* @param ini_id, Origin node Id
* @param end_id, Destination node Id
* @param path, String with the traversed node's name.
* This parameter is modified by the function.
**/
Status graph_deepFirst (Graph *pg, long ini_id, long end_id, char *nodestraversed);


/**@briefPrints a path from the destination node to the origin
 * using the predecessors
 * @paramdev, Stream pointer
 * @param g, Pointer to the graph
 * @param originid, node origin id
 * @paramtoid, node destination id 
 * @return.  Return the number of characters printed.
 * If there have been errors in the Output flow
 * prints an error message in stderror and returns the value -1.
 **/
int pathFromTo (FILE*dev, Graph *g,long orignid, long toid);

/*its recursive function: */
int pathFromTo_rec (FILE *dev, Graph *g, long originid, long actualid);

void clearmain(Graph *g, char *nodestraversed);

int main(int argc, char *argv[]) {
    FILE *f = NULL;
    Graph *g = NULL;
    long ini_id, end_id;
    Status st = OK;
    char *nodestraversed = NULL;

    if (argc!=4)
        return -1;

    if (!(f = fopen(argv[1], "r")))
        return 1;

    if (!(g = graph_init())) {
        fclose(f);
        return 2;
    }

    if (!(nodestraversed = (char *) malloc(sizeof (char) * MAXSTRING))) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 3;
    }

    if (graph_readFromFile(f, g) == ERROR) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 4;
    }

    fclose(f);

    ini_id = strtol(argv[2], NULL, 10);
    end_id = strtol(argv[3], NULL, 10);

    st = graph_deepFirst(g, ini_id, end_id, nodestraversed);

    if (st != END) {
        clearmain(g, nodestraversed);
        return EXIT_FAILURE;
    }

    fprintf(stdout, "Path from Origin to End:\n");
    
    if(pathFromTo(stdout, g, ini_id, end_id) == -1){
        clearmain(g, nodestraversed);
        return EXIT_FAILURE;
    }
    
    fprintf(stdout, "\n");

    clearmain(g, nodestraversed);
    return EXIT_SUCCESS;
}

Status graph_deepFirst(Graph *pg, long ini_id, long end_id, char *nodestraversed) {
    Stack *ps = NULL;
    Node *n = NULL;
    Node *na = NULL;
    Status st = OK, flag_ini = ERROR, flag_end = ERROR;
    long *id = NULL;
    long *con = NULL;
    long i, numNodes, j;
    int ncon;

    if (!pg || !nodestraversed) {
        return ERROR;
    }

    /* initialize stack: */
    if (!(ps = stack_init(node_free, node_copy, node_print))) {
        return ERROR;
    }

    numNodes = graph_getNumberOfNodes(pg);

    if (!(id = graph_getNodesId(pg))) {
        stack_free(ps);
        return 0;
    }

    /* in this next loop at same time as we set all of the nodes to
      * white and the initial one to black, we use flag_ini and
      * flag_end to check that the two nodes actually are in the graph
      */
    for (i = 0; st == OK && i < numNodes; i++) {
        if (!(n = graph_getNode(pg, id[i]))) st = ERROR;
            /* we have to check, because in this function, 
             * a copy of the node is made (and memory is allocated)
             **/

        if (id[i] == ini_id) {
            node_setLabel(n, BLACK);
            flag_ini = OK;
        } else {
            if (id[i] == end_id)
                flag_end = OK;
            node_setLabel(n, WHITE);
        }
        if(st == OK)
            st = graph_setNode(pg, n);
        node_free(n);
        n = NULL;
    }

    if (st == ERROR || flag_end == ERROR || flag_ini == ERROR) {
        stack_free(ps);
        free(id);
        return ERROR;
    }

    if (!(n = graph_getNode(pg, ini_id)) || stack_push(ps, n) == ERROR) {
        stack_free(ps);
        free(id);
        node_free(n);
        return ERROR;
    }
    
    node_free(n);
    
    strncpy(nodestraversed, "", MAXSTRING);

    while (!stack_isEmpty(ps) && st == OK) {
        n = stack_pop(ps);
        
        strncat(nodestraversed, node_getName(n), MAXSTRING);
        strncat(nodestraversed, "\t", MAXSTRING);
        if (node_getId(n) != end_id) {
            con = graph_getConnectionsFrom(pg, node_getId(n));
            ncon = graph_getNumberOfConnectionsFrom(pg, node_getId(n));
            for (j = 0; j < ncon && st == OK; j++) {
                na = graph_getNode(pg, con[j]);
                if(!na) st = ERROR;/*graph_getNode allocates memory*/

                if (node_getLabel(na) == WHITE && st == OK) {
                    node_setLabel(na, BLACK);
                    /* set the predecessor as the node it has been 
                     * explored for the first time from: */
                    node_setPredecessorId(na, node_getId(n));
                    graph_setNode(pg, na);
                    st = stack_push(ps, na);
                }
                node_free(na);
            }
            node_free(n);
            free(con);
        } else { 
            node_free(n);
            st = END;
        }
    }

    stack_free(ps);
    free(id);
    return st;
}


int pathFromTo (FILE *dev, Graph *g, long orignid, long toid){
    if(!dev||!g) return -1;
    
    return pathFromTo_rec(dev, g, orignid, toid);
}

int pathFromTo_rec (FILE *dev, Graph *g, long originid, long actualid){
    int c;
    Node *node = NULL;
    long predid;
    
    /* get current node*/
    if(!(node = graph_getNode (g, actualid))) return -1;
    
    /* Base case*/
    if (originid == actualid) {
        c = node_print (dev, node);
        node_free(node);
        return c;
    }
    
    /* get predecessor id*/
    predid = node_getPredecessorId (node);
    
    /* recursive call*/
    c = pathFromTo_rec (dev, g, originid,  predid);
    
    if (c == -1) return -1;
    
    /* print current node*/        
    c += node_print (dev, node);
    
    node_free (node);
            
    return c;
}
                
                
void clearmain(Graph *g, char *nodestraversed) {
    graph_free(g);
    free(nodestraversed);
}
