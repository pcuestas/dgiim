/* 
 * File:   p3_e1.c
 * Author: Pablo Cuesta
 *
 * Created on 17 de marzo de 2020, 11:14
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "node.h"
#include "graph.h"
#include "queue_fp.h"

void clear_main(Graph *g, Queue *q, long *ids, Node *pn);

int main(int argc, char** argv) {
    Graph *g = NULL;
    FILE *f = NULL;
    Queue *q = NULL;
    long *ids = NULL;
    int sizeG, sizeQ, i;
    Status st = OK;
    Node *pn = NULL;

    if (argc != 2) return -1;

    if (!(g = graph_init())) return 1;

    /*open the file entered in the argument of the main function: */
    if (!(f = fopen(argv[1], "r"))) {
        clear_main(g, q, ids, pn);
        return 2;
    }

    /*read the graph from the file: */
    if (graph_readFromFile(f, g) == ERROR) {
        fclose(f);
        clear_main(g, q, ids, pn);
        return 3;
    }

    fclose(f);

    sizeG = graph_getNumberOfNodes(g);

    /*we get the ids of the nodes in the graph: */
    if (!(ids = graph_getNodesId(g))) {
        clear_main(g, q, ids, pn);
        return 4;
    }

    /*we create the queue: */
    if (!(q = queue_init(node_free, node_copy, node_print))) {
        clear_main(g, q, ids, pn);
        return 5;
    }

    /*we insert all of the nodes of the graph into the queue: */
    for (i = 0; i < sizeG && st == OK; i++) {
        pn = graph_getNode(g, ids[i]);
        st = queue_insert(q, pn);
        node_free(pn);
    }

    if (st == ERROR) {
        clear_main(g, q, ids, pn);
        return 6;
    }

    /*we change the label of the nodes in the graph to BLACK (1) */
    for (i = 0; i < sizeG && st == OK; i++) {
        if(!(pn = graph_getNode(g, ids[i]))) st = ERROR;
                /* we have to check, because in this function, 
                * a copy of the node is made (and memory reserved)
                **/
        
        node_setLabel(pn, BLACK); /*here we do not have to check for an ERROR label,
                                   * because this function will only return ERROR 
                                   * if pn is NULL, which it will never be, in this case*/
        if(st == OK)
            st = graph_setNode(g, pn);
        node_free(pn);
        pn = NULL;
    }

    if (st == ERROR) {
        clear_main(g, q, ids, pn);
        return 7;
    }

    /*print the graph: */
    fprintf(stdout, "\nNodes in the graph: \n");
    
    if (graph_print(stdout, g) < 0) {
        clear_main(g, q, ids, pn);
        return 7;
    }

    sizeQ = queue_size(q);

    fprintf(stdout, "\nQueue size: %d\n", sizeQ);

    /*print the queue: */
    fprintf(stdout, "\nNodes in the queue: \n");

    if (queue_print(stdout, q) < 0) {
        clear_main(g, q, ids, pn);
        return 7;
    }

    /*extract one by one all of the elements of the queue: */
    fprintf(stdout, "\n");
    for (i = 0; i < sizeQ; i++) {
        fprintf(stdout, "\nExtract node: \n");
        pn = queue_extract(q);
        node_print(stdout, pn);
        node_free(pn);
        pn = NULL;
    }

    sizeQ = queue_size(q);

    fprintf(stdout, "\nQueue size: %d\n", sizeQ);

    clear_main(g, q, ids, pn);
    return (EXIT_SUCCESS);
}

void clear_main(Graph *g, Queue *q, long *ids, Node *pn) {
    graph_free(g);
    queue_free(q);
    free(ids);
    node_free(pn);
}
