/* 
 * File:   types.h
 * Author: e422974
 *
 * Created on 4 de febrero de 2020, 10:38
 */

#ifndef TYPES_H
#define TYPES_H
/**
* @brief ADT Boolean
*/
typedef enum {
    FALSE=0, /*!< False value */
    TRUE=1 /*!< True value */
} Bool;
/**
* @brief ADT Status
*/
typedef enum {
    ERROR=0, /*!< To codify an ERROR output */
    OK=1, /*!< OK output */
    END=2
} Status;

#endif /* TYPES_H */
