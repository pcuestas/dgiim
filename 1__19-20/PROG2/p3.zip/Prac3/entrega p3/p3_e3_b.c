/* 
 * File:   p3_e3_b.c
 * Author: Pablo Cuesta, Olmar Arranz
 *
 * Created on 30 de marzo de 2020, 18:08
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "graph.h"
#include "node.h"
#include "queue_fp.h"

#define MAXSTRING 65536

/****
 * @brief Implements the BFS algorithm from an initial node
 * @param pg, Graph
 * @param ini_id, Origin node Id
 * @param end_id, Destination node Id
 * @param path, String with the traversed node's name.
 * This parameter is modified by the function.
 * @return, OK or ERROR if any pointer is NULL
 ****/
Status graph_breadthFirst(Graph *pg, long ini_id, long end_id, char*nodestraversed);

/****
 * @brief Prints a path from the destination node to the origin
 * using the predecessors
 * @param dev, Stream pointer
 * @ param g, Pointer to the graph
 * @param originid, node origin id
 * @param toid, node destination id
 * @return.  Return the number of characters printed.
 * If there have been errors in the Output flow
 * prints an error message in stderror and returns the value -1.
****/
int pathToFrom (FILE*dev, Graph *g, long orignid, long toid);

/* Imprime en un dispositivo el nodo dado del grafo cuyo id, 
* actualid, se le pasa comoparámetro de entrada y que además devuelve,
* a través del parámetropredid,el id del nodo predecesor.
* La función devuelve en su retorno el número decaracteres impresos.
*/
int printNode (FILE*fp,const Graph *g,long actualid,long *predid);

/**@briefPrints a path from the destination node to the origin
 * using the predecessors
 * @paramdev, Stream pointer
 * @param g, Pointer to the graph
 * @param originid, node origin id
 * @paramtoid, node destination id 
 * @return.  Return the number of characters printed.
 * If there have been errors in the Output flow
 * prints an error message in stderror and returns the value -1.
 **/
int pathFromTo (FILE*dev, Graph *g,long orignid, long toid);

/*its recursive function: */
int pathFromTo_rec (FILE *dev, Graph *g, long originid, long actualid);

void clearmain(Graph *g, char *nodestraversed);

int main(int argc, char *argv[]) {
    FILE *f = NULL;
    Graph *g = NULL;
    long ini_id, end_id;
    Status st = OK;
    char *nodestraversed = NULL;

    if (argc!=4)
        return -1;

    if (!(f = fopen(argv[1], "r")))
        return 1;

    if (!(g = graph_init())) {
        fclose(f);
        return 2;
    }

    if (!(nodestraversed = (char *) malloc(sizeof (char) * MAXSTRING))) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 3;
    }

    if (graph_readFromFile(f, g) == ERROR) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 4;
    }

    fclose(f);

    ini_id = strtol(argv[2], NULL, 10);
    end_id = strtol(argv[3], NULL, 10);

    st = graph_breadthFirst(g, ini_id, end_id, nodestraversed);

    if (st != END) {
        clearmain(g, nodestraversed);
        return EXIT_FAILURE;
    }

    fprintf(stdout, "Path from Origin to End:\n");
    
    if(pathFromTo(stdout, g, ini_id, end_id) == -1){
        clearmain(g, nodestraversed);
        return EXIT_FAILURE;
    }
    
    fprintf(stdout, "\nPath from End to Origin:\n");
    
    if(pathToFrom(stdout, g, ini_id, end_id) == -1){
        clearmain(g, nodestraversed);
        return EXIT_FAILURE;
    }
    
    fprintf(stdout, "\n");

    clearmain(g, nodestraversed);
    return EXIT_SUCCESS;
}

Status graph_breadthFirst(Graph *pg, long ini_id, long end_id, char *nodestraversed) {
    Queue *q = NULL;
    Node *n = NULL;
    Node *na = NULL;
    Status st = OK, flag_ini = ERROR, flag_end = ERROR;
    long *id = NULL;
    long *con = NULL;
    long i, numNodes, j;
    int ncon;

    if (!pg || !nodestraversed) {
        return ERROR;
    }

    /* initialize queue: */
    if (!(q = queue_init(node_free, node_copy, node_print))) {
        return ERROR;
    }

    numNodes = graph_getNumberOfNodes(pg);

    if (!(id = graph_getNodesId(pg))) {
        queue_free(q);
        return 0;
    }

    /* in this next loop at same time as we set all of the nodes to
      * white and the initial one to black, we use flag_ini and
      * flag_end to check that the two nodes actually are in the graph
      */
    for (i = 0; st == OK && i < numNodes; i++) {
        if (!(n = graph_getNode(pg, id[i]))) st = ERROR;
            /* we have to check, because in this function, 
             * a copy of the node is made (and memory is allocated)
             **/

        if (id[i] == ini_id) {
            node_setLabel(n, BLACK);
            flag_ini = OK;
        } else {
            if (id[i] == end_id)
                flag_end = OK;
            node_setLabel(n, WHITE);
        }
        if(st == OK)
            st = graph_setNode(pg, n);
        node_free(n);
        n = NULL;
    }

    if (st == ERROR || flag_end == ERROR || flag_ini == ERROR) {
        queue_free(q);
        free(id);
        return ERROR;
    }

    if (!(n = graph_getNode(pg, ini_id)) || queue_insert(q, n) == ERROR) {
        queue_free(q);
        free(id);
        node_free(n);
        return ERROR;
    }
    
    node_free(n);
    
    strncpy(nodestraversed, "", MAXSTRING);

    while (!queue_isEmpty(q) && st == OK) {
        n = queue_extract(q);
        
        strncat(nodestraversed, node_getName(n), MAXSTRING);
        strncat(nodestraversed, "\t", MAXSTRING);
        if (node_getId(n) != end_id) {
            con = graph_getConnectionsFrom(pg, node_getId(n));
            ncon = graph_getNumberOfConnectionsFrom(pg, node_getId(n));
            for (j = 0; j < ncon && st == OK; j++) {
                na = graph_getNode(pg, con[j]);
                if(!na) st = ERROR;/*graph_getNode allocates memory*/

		/*if na==NULL, its label won't be white, so we don't have to check st: */
                if (node_getLabel(na) == WHITE) { 
                    node_setLabel(na, BLACK);
                    /* set the predecessor as the node it has been 
                     * explored for the first time from: */
                    if(st==OK)
                        st = node_setPredecessorId(na, node_getId(n));
                    if(st==OK)                    
                        st = graph_setNode(pg, na);
                    if(st == OK)
                        st = queue_insert(q, na);
                }
                node_free(na);
            }
            node_free(n);
            free(con);
        } else { 
            node_free(n);
            st = END;
        }
    }

    queue_free(q);
    free(id);
    return st;
}

int pathToFrom (FILE*dev, Graph *g, long orignid, long toid){
    int c = 0, check = 0;
    long id = toid;

    while(id != orignid && check != -1){
        /*necessary check, as printNode allocates memory: */
        check = printNode(dev, g, id, &id);
        c += check;
    }

    if (check == -1) return -1;

    check = printNode(dev, g, id, &id);
    c += check;

    if (check == -1) return -1;

    return c;
}


int printNode (FILE*fp,const Graph *g, long actualid, long *predid){
    Node* pn=NULL;
    int c;

    if(!g||!fp) return -1;
    
    if(!(pn = graph_getNode(g, actualid))) return -1;

    (*predid) = node_getPredecessorId(pn);

    c = node_print(fp, pn);

    node_free(pn);

    return c;
}

int pathFromTo (FILE *dev, Graph *g, long orignid, long toid){
    if(!dev||!g) return -1;
    
    return pathFromTo_rec(dev, g, orignid, toid);
}

int pathFromTo_rec (FILE *dev, Graph *g, long originid, long actualid){
    int c;
    Node *node = NULL;
    long predid;
    
    /* get current node*/
    if(!(node = graph_getNode (g, actualid))) return -1;
    
    /* Base case*/
    if (originid == actualid) {
        c = node_print (dev, node);
        node_free(node);
        return c;
    }
    
    /* get predecessor id*/
    predid = node_getPredecessorId (node);
    
    /* recursive call*/
    c = pathFromTo_rec (dev, g, originid,  predid);
    
    if (c == -1) return -1;
    
    /* print current node*/        
    c += node_print (dev, node);
    
    node_free (node);
            
    return c;
}
                
                
void clearmain(Graph *g, char *nodestraversed) {
    if (g != NULL)
        graph_free(g);
    if (nodestraversed != NULL)
        free(nodestraversed);
}
