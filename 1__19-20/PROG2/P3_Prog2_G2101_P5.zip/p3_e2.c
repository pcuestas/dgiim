#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "graph.h"
#include "node.h"
#include "queue_fp.h"

#define MAXSTRING 65536

/****
 * @brief Implements the BFS algorithm from an initial node
 * @param pg, Graph* @param ini_id, Origin node Id
 * @param end_id, Destination node Id
 * @param path, String with the traversed node's name.
 * This parameter is modified by the function.
 * @return, OK or ERROR if any pointer is NULL
 ****/
Status graph_breadthFirst(Graph *pg, long ini_id, long end_id, char*nodestraversed);

void clearmain(Graph *g, char *nodestraversed);

int main(int argc, char *argv[]) {
    FILE *f = NULL;
    Graph *g = NULL;
    long ini_id, end_id;
    Status st = OK;
    char *nodestraversed = NULL;

    if (argc != 4)
        return -1;

    if (!(f = fopen(argv[1], "r")))
        return 1;

    if (!(g = graph_init())) {
        fclose(f);
        return 2;
    }

    if (!(nodestraversed = (char *) malloc(sizeof (char) * MAXSTRING))) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 3;
    }

    if (graph_readFromFile(f, g) == ERROR) {
        fclose(f);
        clearmain(g, nodestraversed);
        return 4;
    }

    fclose(f);

    ini_id = strtol(argv[2], NULL, 10);
    end_id = strtol(argv[3], NULL, 10);

    st = graph_breadthFirst(g, ini_id, end_id, nodestraversed);

    if (st == END) {
        fprintf(stdout, "\n%s\n", nodestraversed);
        clearmain(g, nodestraversed);
        return EXIT_SUCCESS;
    }

    clearmain(g, nodestraversed);
    return EXIT_FAILURE;
}

Status graph_breadthFirst(Graph *pg, long ini_id, long end_id, char *nodestraversed) {
    Queue *q = NULL;
    Node *n = NULL;
    Node *na = NULL;
    Status st = OK, flag_ini = ERROR, flag_end = ERROR;
    long *id = NULL;
    long *con = NULL;
    long i, numNodes, j;
    int ncon;

    if (!pg || !nodestraversed) {
        return ERROR;
    }

    /* initialize queue: */
    if (!(q = queue_init(node_free, node_copy, node_print))) {
        return ERROR;
    }

    numNodes = graph_getNumberOfNodes(pg);

    if (!(id = graph_getNodesId(pg))) {
        queue_free(q);
        return 0;
    }

    for (i = 0; st == OK && i < numNodes; i++) {
        if (!(n = graph_getNode(pg, id[i]))) st = ERROR;
            /* we have to check, because in this function, 
             * a copy of the node is made (and memory is allocated)
             **/

        if (id[i] == ini_id) {
            node_setLabel(n, BLACK);
            flag_ini = OK;
        } else {
            if (id[i] == end_id)
                flag_end = OK;
            node_setLabel(n, WHITE);
        }
        if(st == OK)
            st = graph_setNode(pg, n);
        node_free(n);
        n = NULL;
    }

    if (st == ERROR || flag_end == ERROR || flag_ini == ERROR) {
        queue_free(q);
        free(id);
        return ERROR;
    }

    if (!(n = graph_getNode(pg, ini_id)) || queue_insert(q, n) == ERROR) {
        queue_free(q);
        free(id);
        node_free(n);
        return ERROR;
    }
    
    node_free(n);
    
    strncpy(nodestraversed, "", MAXSTRING);

    while (!queue_isEmpty(q) && st == OK) {
        n = queue_extract(q);
        
        strncat(nodestraversed, node_getName(n), MAXSTRING);
        strncat(nodestraversed, "    ", MAXSTRING);
        if (node_getId(n) != end_id) {
            con = graph_getConnectionsFrom(pg, node_getId(n));
            ncon = graph_getNumberOfConnectionsFrom(pg, node_getId(n));
            for (j = 0; j < ncon && st == OK; j++) {
                na = graph_getNode(pg, con[j]);
                if(!na) st = ERROR;/*graph_get node allocates memory*/

                if (node_getLabel(na) == WHITE && st == OK) {
                    node_setLabel(na, BLACK);
                    graph_setNode(pg, na);
                    st = queue_insert(q, na);
                }
                node_free(na);
            }
            node_free(n);
            free(con);
        } else {
            node_free(n);
            st = END;
        }
    }

    queue_free(q);
    free(id);
    return st;
}

void clearmain(Graph *g, char *nodestraversed) {
        graph_free(g);
        free(nodestraversed);
}








