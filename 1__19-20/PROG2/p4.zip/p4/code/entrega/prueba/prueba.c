/*
 * File:   prueba
 * Autor: pablo
 */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

#include "graph_list.h"
#include "types.h"
#include "node.h"


int main(int argc, char** argv) {
    Graph *g = NULL;
    Node  *n = NULL;
    char name[200];
    
    
    g = graph_init();


    n = node_init();
	/*nodo 1*/
	strncpy(name, "nodo1", 200);
    node_setId(n,1);
    node_setName(n, name);
    node_setLabel(n,0);
    
    graph_insertNode(g, n);
    
    /*nodo 2*/
    strncpy(name, "nodo2", 200);
    node_setId(n,2);
    node_setName(n, name);
    node_setLabel(n,0);

    graph_insertNode(g, n);

    /*1 y 2 conectados*/
    graph_insertEdge(g,1,2);
    graph_insertEdge(g,2,1);
    
    /*nodo 3*/
    strncpy(name, "nodo3", 200);
    node_setId(n,3);
    node_setName(n, name);
    node_setLabel(n,0);

    graph_insertNode(g, n);
    
    /*se imprime grafo*/
    graph_print(stdout, g);
    
    graph_free(g);
    node_free(n);

    return (EXIT_SUCCESS);
}

