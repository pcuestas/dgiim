/* 
 * File:   graph_list.c
 * Author: pablo
 * 
 * Created on 21 de abril de 2020, 12:30
 */

#include "graph_list.h"

#define MAX_NODES 1064
#define MAX_LINE 100

struct _Graph {
    List *plnode; /*!<List with the graph nodes */
    Bool connections[MAX_NODES][MAX_NODES]; /*!<Adjacency matrix */
    int num_nodes; /*!<Total number of nodes in the graph */
    int num_edges; /*!<Total number of connections in the graph*/
};

/*private functions:*/
int find_node_index(const Graph * g, int nId1) {
    int position;
    Node *pn = NULL;

    if (!g)
        return -1;

    if (!(pn = node_init()))
        return -1;

    if (node_setId(pn, nId1) == ERROR) {
        node_free(pn);
        return -1;
    }

    position = list_getPositionElement(g->plnode, pn);

    node_free(pn);

    if(position == -1) return -1;

    /*nodes are in reverse order in the list, so: */
    position = g->num_nodes - position - 1;

    return position;
}

int* graph_getConnectionsIndex(const Graph *g, int index) {
    int *array = NULL, i, j = 0, size;

    if (!g) return NULL;

    if (index < 0 || index > g->num_nodes) return NULL;

    /* get memory for the array*/
    size = node_getConnect(list_getElementInPos(g->plnode, g->num_nodes - 1 - index));
    array = (int *) malloc(sizeof (int) * size);

    if (!array || size < 0) {
        /* print error message*/
        fprintf(stderr, "%s\n", strerror(errno));
        return NULL;
    }

    /*assign values to the array with the indices of the connected nodes*/
    for (i = 0; i < g->num_nodes; i++) {
        if (g->connections[index][i] == TRUE) {
            array[j] = i;
            j++;
        }
    }

    return array;
}

/****public functions****/

Graph * graph_init() {
    Graph *g = NULL;
    int i, j;

    if (!(g = (Graph*) malloc(sizeof (Graph))))
        return NULL;

    g->plnode = list_new(node_free, node_copy, node_print, node_cmp);

    if (g->plnode == NULL) {
        free(g);
        return NULL;
    }

    for (i = 0; i < MAX_NODES; i++)
        for (j = 0; j < MAX_NODES; j++)
            g->connections[i][j] = FALSE;

    g->num_nodes = 0;
    g->num_edges = 0;

    return g;
}

void graph_free(Graph *g) {
    if (!g) return;

    list_free(g->plnode);

    free(g);
}

Status graph_insertNode(Graph *g, const Node *n) {
    if (!g || !n)
        return ERROR;

    if (find_node_index(g, node_getId(n)) != -1)
        return OK; /*this means the node is alredy in the graph*/

    if (list_pushFront(g->plnode, n) == ERROR)
        return ERROR;

    (g->num_nodes)++;

    return OK;
}

Status graph_insertEdge(Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;
    Node *node1 = NULL;

    if (!g || nId2 == nId1) return ERROR;

    if ((pos1 = find_node_index(g, nId1)) == -1) return ERROR;
    if ((pos2 = find_node_index(g, nId2)) == -1) return ERROR;

    /*we get the node, not a copy, in pos1*/
    node1 = list_getElementInPos(g->plnode, g->num_nodes - 1 - pos1);

    if (node1 == NULL)
        return ERROR;

    if (graph_areConnected(g, nId1, nId2) == FALSE) {
        g->connections[pos1][pos2] = TRUE;
        node_setNConnect(node1, node_getConnect(node1) + 1);
        (g->num_edges)++;
    }

    return OK;
}

Node *graph_getNode(const Graph *g, long nId) {
    Node *copy = NULL, *node = NULL;
    int position;

    if (!g)
        return NULL;

    if ((position = find_node_index(g, nId)) == -1)
        return NULL;

    node = list_getElementInPos(g->plnode, g->num_nodes - 1 - position);

    /*no need to check node, if it is NULL, copy will 
     * also be NULL, and we can check only that*/

    copy = node_copy(node);

    /*if there is an error, copy will be null 
     * so the funciton will return null*/

    return copy;
}

Status graph_setNode(Graph *g, const Node *n) {
    Node *node = NULL;
    int position;

    if (!g || !n)
        return ERROR;

    if ((position = find_node_index(g, node_getId(n))) == -1)
        return ERROR;

    /*we get the node, not a copy, in that position*/
    node = list_getElementInPos(g->plnode, g->num_nodes - 1 - position);

    if (!node)
        return ERROR;

    /*no need to check the following functios for 
     * errors as thay only fail if the nodes are 
     * NULL, which they are not*/
    node_setName(node, node_getName((Node*) n));
    node_setLabel(node, node_getLabel(n));
    node_setNConnect(node, node_getConnect(n));
    node_setPredecessorId(node, node_getPredecessorId(n));

    return OK;
}


long * graph_getNodesId(const Graph *g){
    long *Ids, i;
    Node *node=NULL;

    if (!g)return NULL;

    if (!(Ids = (long*) malloc((g->num_nodes) * sizeof (long)))) 
        return NULL;

    for (i = 0; i < g->num_nodes; i++){
        if (!(node = list_getElementInPos(g->plnode, g->num_nodes - 1 - i))){
            free(Ids);
            return NULL;
        }
        Ids[i] = node_getId(node);
        node = NULL;
    }

    return Ids;
}

int graph_getNumberOfNodes(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_nodes;
}

int graph_getNumberOfEdges(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_edges;
}

Bool graph_areConnected(const Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;

    if (!g) return FALSE;

    if ((pos1 = find_node_index(g, nId1)) == -1) return FALSE;
    if ((pos2 = find_node_index(g, nId2)) == -1) return FALSE;

    return g->connections[pos1][pos2];
}

int graph_getNumberOfConnectionsFrom(const Graph *g, const long fromId) {
    int pos;
    Node *node = NULL;

    if (!g) 
        return -1;

    if ((pos = find_node_index(g, fromId)) == -1) 
        return -1;

    node = list_getElementInPos(g->plnode, g->num_nodes - 1 - pos);

    if (!node) 
        return -1;

    return node_getConnect(node);
}



long* graph_getConnectionsFrom(const Graph *g, const long fromId) {
    long *Ids = NULL;
    int i, j, pos, nconnections;
    Node *node = NULL, *node_i = NULL;

    /*check pointer*/
    if (!g)
        return NULL;

    /*check if node with that id is in the graph and get its index*/
    if ((pos = find_node_index(g, fromId)) == -1)
        return NULL;

    node = list_getElementInPos(g->plnode, g->num_nodes - 1 - pos);

    if (!node)
        return NULL;

    nconnections = node_getConnect(node);

    /*we allocate the memory for the array of ids*/
    if (!(Ids = (long*) calloc(nconnections, (sizeof (long)))))
        return NULL;

    /*for every node connected to g->nodes[index], we keep its id in Ids.*/
    for (i = j = 0; i < g->num_nodes; i++) {
        if (g->connections[pos][i] == TRUE) {
            if (!(node_i = list_getElementInPos(g->plnode, g->num_nodes - 1 - i)))
                return NULL;
            Ids[j] = node_getId(node_i);
            j++;
            node_i = NULL;
        }

    }

    return Ids;

}


int graph_print(FILE *pf, const Graph *g) {
    int i, j, cha = 0, connect;
    long *Ids;
    Node *node = NULL;

    if (!pf || !g) {
        fprintf(stderr, "%s\n", strerror(errno));
        return -1;
    }


    for (i = 0; i < g->num_nodes; i++) {
        if (!(node = list_getElementInPos(g->plnode, g->num_nodes - 1 - i)))
            return -1;
        
        cha += node_print(pf, node);

        /*get the array of ids of nodes connected to node with index i:*/
        if (!(Ids = graph_getConnectionsFrom(g, node_getId(node)))) {
            fprintf(stderr, "%s\n", strerror(errno));
            return -1;
        }
        
        connect = node_getConnect(node);

        /*print ids of all nodes connected to node with index i*/
        for (j = 0; j < connect; j++) {
            cha += fprintf(pf, " %ld", Ids[j]);
        }

        free(Ids);
        fprintf(pf, "\n");
    }

    return cha;
}

Status graph_readFromFile(FILE *fin, Graph *g){
    Node *n;
    int nnodes;
    char buff[MAX_LINE], name[NAME_L];
    int i;
    long id1, id2;
    int label;
    Status flag = OK;


    if (!fin || !g) return ERROR;

    if (!(n = node_init())) return ERROR;

    if (fgets(buff, MAX_LINE, fin) != NULL)
        if (sscanf(buff, "%d", &nnodes) != 1)return ERROR;

    for (i = 0; i < nnodes && flag == OK; i++) {

        if (fgets(buff, MAX_LINE, fin)) {

            if (sscanf(buff, "%ld %s %d", &id1, name, &label) == 3) {
                node_setId(n, id1);
                node_setLabel(n, label);
                node_setName(n, name);
                flag = graph_insertNode(g, n);
            } else flag = ERROR;

        } else flag = ERROR;
    }

    if (i < nnodes) flag = ERROR;

    while (flag == OK && (fgets(buff, MAX_LINE, fin) != NULL)) {
        if (sscanf(buff, "%ld %ld", &id1, &id2) == 2) {
            flag = graph_insertEdge(g, id1, id2);
        } else flag = ERROR;
    }

    node_free(n);

    if (!feof(fin))
        flag = ERROR;

    return flag;

}


