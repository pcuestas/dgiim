/* 
 * File:   p4_e3_a.c
 * Author: pablo
 *
 * Created on 28 de abril de 2020, 11:24
 */

#include <stdio.h>
#include <stdlib.h>

#include "node.h"
#include "graph_list.h"
#include "tree.h"

Status clear_main(Status error, Graph *g, BSTree *t);

Status insert_nodesFromGraphToTree(Graph *g, BSTree *t);

int main(int argc, char** argv) {
    Graph *g = NULL;
    FILE *f;
    BSTree *t = NULL;

    if (argc != 2) {
        fprintf(stderr, "This program requires an argument: the name of a file that contains a graph\n%s\n", strerror(errno));
        return EXIT_FAILURE;
    }
    if (!(f = fopen(argv[1], "r")))
        return EXIT_FAILURE;

    if (!(g = graph_init())) {
        fclose(f);
        return EXIT_FAILURE;
    }

    if (graph_readFromFile(f, g) == ERROR) {
        fclose(f);
        return clear_main(EXIT_FAILURE, g, t);
    }

    fclose(f);

    if (!(t = tree_init(node_free, node_copy, node_print, node_cmp))) {
        return clear_main(EXIT_FAILURE, g, t);
    }

    if (insert_nodesFromGraphToTree(g, t) == ERROR) {
        return clear_main(EXIT_FAILURE, g, t);
    }

    printf("Printing graph ...\n");
    if (graph_print(stdout, g) < 0)
        return clear_main(EXIT_FAILURE, g, t);

    printf("\nTree inOrder ...\n");
    if (tree_inOrder(stdout, t) < 0)
        return clear_main(EXIT_FAILURE, g, t);

    printf("\n\nTree preOrder ...\n");
    if (tree_preOrder(stdout, t) < 0)
        return clear_main(EXIT_FAILURE, g, t);
    
    printf("\n\nTree postOrder ...\n");
    if (tree_postOrder(stdout, t) < 0)
        return clear_main(EXIT_FAILURE, g, t);
        
    printf("\n\n");

    return clear_main(EXIT_SUCCESS, g, t);
}

Status insert_nodesFromGraphToTree(Graph *g, BSTree *t) {
    long *Ids = NULL;
    Node *pn = NULL;
    int num_nodes, i;
    Status st = OK;

    if (!g || !t)
        return ERROR;

    if (!(Ids = graph_getNodesId(g)))
        return ERROR;

    num_nodes = graph_getNumberOfNodes(g);

    for (i = 0; i < num_nodes && st == OK; i++) {

        if (!(pn = graph_getNode(g, Ids[i]))) {
            free(Ids);
            return ERROR;
        }

        st = tree_insert(t, pn);

        node_free(pn);
        pn = NULL;
    }
    free(Ids);

    return st;
}

Status clear_main(Status error, Graph *g, BSTree *t) {
    graph_free(g);
    tree_destroy(t);

    return error;
}
