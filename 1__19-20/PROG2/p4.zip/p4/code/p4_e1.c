/*
 * File:   p4_e1.c
 * Author: pablo
 *
 * Created on 19 de abril de 2020, 17:42
 */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

#include "list.h"
#include "stack_fp.h"
#include "types.h"


#define MAX_ID 1000

/**
 * @brief This functión insert n random integers between 0 and MAX_ID into
 * an ordered list.
 *
 * This functions modifies the list input parameter.
 *
 * @param n, Length of the list
 * @param pl, Address of object list
 * @return This function returns OK or ERROR.
 **/
Status listOfRandomOrdered(int n, List *pl);

/* Type definition. Pointer function to compare two elements */
typedef int (*f_cmp_type)(const void *, const void*);

/**
 * @brief This function concatenate two increased ordered lists
 *
 * This functions does not modified the ordered input lists l1 and l2.
 *
 * @parameter l1, Pointer to one list
 * @parameter l2, Pointer to the second list
 * @parameter lout, Pointer to the output concatenated list
 * @parameter fun, Function used to compare the list elements
 * 
 * @return This function returns OK or ERROR.
 **/
Status listMergeOrdered(List *l1, List *l2, List *lout, f_cmp_type fun);

/**
 * @brief this function extracts form the beginning of the list l one
 *          by one all of its items and tores them in order in the stack s
 * 
 * @param l, list that is going to be emptied
 * @param s, stack where the items from the list will be stored
 * @return OK or ERROR
 */
Status emptyListInStack(List *l, Stack *s);

void *int_copy(const void *i) {
    int *j = NULL;

    if (!i) return NULL;

    if (!(j = (int*) malloc(sizeof (int))))return NULL;

    *j = *(int*) i;

    return j;
}

int int_print(FILE *f, const void *i) {
    if (!i)return -1;

    return fprintf(f, "%d ", *(int*) i);
}

int int_cmp(const void *i, const void *j) {
    if (!i || !j) return 0;

    return ((*(int*) i)-(*(int*) j));
}

int clean_main(List *l1, List *l2, List *lout, Status error) {
    list_free(l1);
    l1 = NULL;

    list_free(l2);
    l2 = NULL;

    list_free(lout);
    lout = NULL;

    return error;
}

int main(int argc, char** argv) {
    List *l1 = NULL, *l2 = NULL, *lout = NULL;
    Status st = OK;
    int n;

    if (argc != 2) {
        fprintf(stdout, "This main requires one argument, an integer(size of the initial lists)\n");
        return (EXIT_FAILURE);
    }
    
    n = atoi(argv[1]);

    l1 = list_new(free, int_copy, int_print, int_cmp);
    l2 = list_new(free, int_copy, int_print, int_cmp);
    lout = list_new(free, int_copy, int_print, int_cmp);

    if (!l1 || !l2 || !lout)
        return clean_main(l1, l2, lout, EXIT_FAILURE);

    st = listOfRandomOrdered (n, l1);

    if(st==OK)
        st = listOfRandomOrdered (n, l2);
        
    if (listMergeOrdered(l1, l2, lout, int_cmp) == ERROR || st == ERROR)
        return clean_main(l1, l2, lout, EXIT_FAILURE);

    fprintf(stdout, "List 1:\n");

    list_print(stdout, l1);
    fprintf(stdout, " Size: %d\nList 2:\n", list_size(l1));

    list_print(stdout, l2);
    fprintf(stdout, " Size: %d\nList 3:\n", list_size(l2));

    list_print(stdout, lout);
    fprintf(stdout, " Size: %d\n", list_size(lout));

    return clean_main(l1, l2, lout, (EXIT_SUCCESS));
}

Status listMergeOrdered(List *l1, List *l2, List *lout, f_cmp_type fun) {
    Status st = OK;
    Stack *s1 = NULL, *s2 = NULL, *saux = NULL;
    List *laux = NULL;
    void *ele = NULL;

    if (!l1 || !l2 || !lout || list_isEmpty(lout) == FALSE)
        return ERROR;

    /* for the initialization of the stacks we need the functios that 
     * will be used for the treatments of the itams inserted, but if 
     * they are not entered as arguments, we have no access to that information 
     * so we have to lose a bit of abstraction 
     */
    if (!(s1 = stack_init(free, int_copy, int_print)))
        return ERROR;
    if (!(s2 = stack_init(free, int_copy, int_print))) {
        stack_free(s1);
        return ERROR;
    }

    st = emptyListInStack(l1, s1);

    if (st == OK)
        st = emptyListInStack(l2, s2);

    while (stack_isEmpty(s1) == FALSE && stack_isEmpty(s2) == FALSE && st == OK) {
        if (fun(stack_top(s1), stack_top(s2)) < 0) {
            ele = stack_pop(s2);
            st = list_pushFront(l2, ele);
        } else {
            ele = stack_pop(s1);
            st = list_pushFront(l1, ele);
        }
        if (st == OK)
            st = list_pushFront(lout, ele);

        /* as we do not know this element, this function 
         * frees any pointer to char, integer, long...
         * so it is ok for what we want
         */
        free(ele);
        ele = NULL;
    }

    if (st == ERROR)
        return st;

    if (stack_isEmpty(s1) == TRUE) {
        laux = l2;
        saux = s2;
    } else {
        laux = l1;
        saux = s1;
    }

    while (stack_isEmpty(saux) == FALSE && st == OK) {
        ele = stack_pop(saux);
        st = list_pushFront(laux, ele);

        if (st == OK)
            st = list_pushFront(lout, ele);

        free(ele);
        ele = NULL;
    }

    stack_free(s1);
    stack_free(s2);

    return st;
}

Status emptyListInStack(List *l, Stack *s) {
    void *element = NULL;
    Status st = OK;

    if (!s || !l)
        return ERROR;

    while (list_isEmpty(l) == FALSE && st == OK) {
        element = list_popFront(l);
        st = stack_push(s, element);
        free(element);
        element = NULL;
    }

    return st;
}

Status listOfRandomOrdered(int n, List *pl) {
    int i, x;
    Status st = OK;

    if (!pl) return ERROR;

    for (i = 0; i < n && st == OK; i++) {
        x = rand() % MAX_ID;
        st = list_pushOrder(pl, &x, 1);
    }

    if (st == ERROR) {
        fprintf(stderr, "%s\n", strerror(errno));
        return ERROR;
    }

    return OK;
}
