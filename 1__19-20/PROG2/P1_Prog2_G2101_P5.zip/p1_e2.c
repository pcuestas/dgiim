/* 
 * File:   main.c
 * 
 * Description: exercise 1 from practice 2
 * 
 * Author: Pablo Cuesta, Olmar Arranz
 *
 * Created on 11 de febrero de 2020, 18:49
 * 
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "graph.h"
#include "node.h"

int main(int argc, char** argv) {
    Node *n1 = NULL;
    Node *n2 = NULL;
    Graph *g;

    /*initialize both nodes and check for errors*/
    if (!(n1 = node_init()))
        return 1;
    if (!(n2 = node_init())) {
        node_free(n1);
        return 1;
    }

    /*we make the changes in name, label and id*/
    node_setName(n1, "first");
    node_setName(n2, "second");
    node_setId(n1, 111);
    node_setId(n2, 222);
    node_setLabel(n1, WHITE);
    node_setLabel(n2, WHITE);

    /*inicialize a graph*/
    if (!(g = graph_init())) {
        node_free(n1);
        node_free(n2);
        return 1;
    }

    /*insert both nodes:*/
    printf("Insertando nodo 1...resultado...: %hu\n", graph_insertNode(g, n1));
    printf("Insertando nodo 2...resultado...: %hu\n", graph_insertNode(g, n2));

    /*connect node 2 to node 1:*/
    printf("Insertando edge: nodo 2 -----> nodo 1\n");

    if (graph_insertEdge(g, node_getId(n2), node_getId(n1)) == 0) {
        graph_free(g);
        node_free(n1);
        node_free(n2);
        return 1;
    }

    /*check connections between nodes:*/
    printf("¿Conectados nodo 1 y nodo 2? ");

    if (graph_areConnected(g, node_getId(n1), node_getId(n2)))
        printf("Sí\n");
    else printf("No\n");

    printf("¿Conectados nodo 2 y nodo 1? ");

    if (graph_areConnected(g, node_getId(n2), node_getId(n1)))
        printf("Sí\n");
    else printf("No\n");

    /*we try to insert node 2 again:*/
    printf("Insertando nodo 2....resultado: %hu\n", graph_insertNode(g, n2));

    /*print the graph:*/
    printf("Grafo: \n");
    graph_print(stdout, g);
    
    
    node_free(n1);
    node_free(n2);
    graph_free(g);

    return (EXIT_SUCCESS);
}
