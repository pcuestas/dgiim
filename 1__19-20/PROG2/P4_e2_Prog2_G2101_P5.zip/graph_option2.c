/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   graph_option2.c
 * Author: pablo
 * 
 * Created on 25 de abril de 2020, 11:02
 */

#include "graph_option2.h"
#include "list.h"

#define INITIAL_CAPACITY 2
#define MAX_LINE 100

struct _Graph {
    Node **nodes; /*!<Dynamic array with the graph nodes */
    List **plconnect; /*!<Adjacency dynamic array list */
    int num_nodes; /*!<Total number of nodes in the graph */
    int num_edges; /*!<Total number of connections in the graph */
    int capacity; /*!<Current size of the dynamically allocated array*/
};


/*private functions:*/
int find_node_index(const Graph * g, int nId1);

int* graph_getConnectionsIndex(const Graph *g, int index);

/* @brief doubles capacity of graph or leaves it untouched if 
 * there is no sufficient memory
 * 
 * @param g: graph
 * 
 * @return OK or ERROR 
 */
Status graph_doubleCapacity(Graph *g);

void *long_copy(const void *i) {
    long *j = NULL;

    if (!i) return NULL;

    if (!(j = (long*) malloc(sizeof (long))))return NULL;

    *j = *(long*) i;

    return j;
}

int long_print(FILE *f, const void *i) {
    if (!i)return -1;

    return fprintf(f, "%ld ", *(long*) i);
}

int long_cmp(const void *i, const void *j) {
    if (!i || !j) return 0;

    return ((*(long*) i)-(*(long*) j));
}

/***public functions******/

Graph * graph_init() {
    Graph *g = NULL;
    int i;

    if (!(g = (Graph*) malloc(sizeof (Graph))))
        return NULL;

    /* allocate mamory in the array of nodes for two nodes*/
    if (!((g->nodes) = (Node**) malloc(INITIAL_CAPACITY * sizeof (Node*)))) {
        free(g);
        return NULL;
    }

    /* allocate mamory in the array of 
     * lists for the conections of two nodes*/
    if (!((g->plconnect) = (List**) malloc(INITIAL_CAPACITY * sizeof (List*)))) {
        free(g->nodes);
        free(g);
        return NULL;
    }

    for (i = 0; i < INITIAL_CAPACITY; i++) {
        g->nodes[i] = NULL;
        g->plconnect[i] = NULL;
    }
    /* I choose not to reserve memory for each list, that 
     * will be made when we add each new node*/

    g->num_nodes = 0;
    g->num_edges = 0;
    g->capacity = INITIAL_CAPACITY;

    return g;
}

void graph_free(Graph *g) {
    int i;

    if (!g) return;

    for (i = 0; i < g->num_nodes; i++) {
        node_free(g->nodes[i]);
        list_free(g->plconnect[i]);
    }

    free(g->nodes);
    free(g->plconnect);
    free(g);
}

Status graph_insertNode(Graph *g, const Node *n) {
    if (!g || !n)
        return ERROR;

    if (find_node_index(g, node_getId(n)) != -1)
        return graph_setNode(g, n); /*it is already in the graph
                                     * so it gets updated
                                     */

    if (g->capacity == g->num_nodes)
        if (graph_doubleCapacity(g) == ERROR)
            return ERROR;

    /* reserve memory for the connections list*/
    if (!(g->plconnect[g->num_nodes] = list_new(free, long_copy, long_print, long_cmp)))
        return ERROR;

    /* check if the copy has been succesfully completed: */
    if (!(g->nodes[g->num_nodes] = node_copy(n))) {
        list_free(g->plconnect[g->num_nodes]);
        return ERROR;
    }

    /* if everything has happened correctly, 
     * add 1 to the number of nodes*/

    (g->num_nodes)++;

    return OK;
}

Status graph_insertEdge(Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;

    if (!g || nId2 == nId1) return ERROR;

    if ((pos1 = find_node_index(g, nId1)) == -1) return ERROR;
    if ((pos2 = find_node_index(g, nId2)) == -1) return ERROR;

    if (graph_areConnected(g, nId1, nId2) == FALSE) {
        list_pushFront(g->plconnect[pos1], &nId2);
        node_setNConnect(g->nodes[pos1], node_getConnect(g->nodes[pos1]) + 1);
        (g->num_edges)++;
    }

    return OK;
}

Node *graph_getNode(const Graph *g, long nId) {
    int index;
    Node *aux = NULL;

    if (!g) return NULL;
    if ((index = find_node_index(g, nId)) == -1) return NULL;

    if (!(aux = node_copy(g->nodes[index]))) return NULL;

    return aux;
}

Status graph_setNode(Graph *g, const Node *n) {
    int index;

    if (!g || !n)
        return ERROR;

    if ((index = find_node_index(g, node_getId(n))) == -1)
        return ERROR;

    node_setName(g->nodes[index], node_getName((Node*) n));
    node_setLabel(g->nodes[index], node_getLabel(n));
    node_setNConnect(g->nodes[index], node_getConnect(n));
    node_setPredecessorId(g->nodes[index], node_getPredecessorId(n));

    return OK;
}

long * graph_getNodesId(const Graph *g) {
    long *Ids, i;

    if (!g)return NULL;

    if (!(Ids = (long*) malloc((g->num_nodes) * sizeof (long))))
        return NULL;

    for (i = 0; i < g->num_nodes; i++)
        Ids[i] = node_getId(g->nodes[i]);

    return Ids;
}

int graph_getNumberOfNodes(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_nodes;
}

int graph_getNumberOfEdges(const Graph *g) {
    if (!g)
        return -1;
    else
        return g->num_edges;
}

Bool graph_areConnected(const Graph *g, const long nId1, const long nId2) {
    int pos1, pos2;

    if (!g) return FALSE;

    if ((pos1 = find_node_index(g, nId1)) == -1) return FALSE;
    if ((pos2 = find_node_index(g, nId2)) == -1) return FALSE;

    if (list_getPositionElement(g->plconnect[pos1], &nId2) != -1)
        return TRUE;
    else
        return FALSE;
}

int graph_getNumberOfConnectionsFrom(const Graph *g, const long fromId) {
    int pos;

    if (!g) return -1;

    if ((pos = find_node_index(g, fromId)) == -1) 
        return -1;

    return node_getConnect(g->nodes[pos]);
}

long* graph_getConnectionsFrom(const Graph *g, const long fromId) {
    long *Ids = NULL, toId;
    int i, j, index, nconnections;

    /*check pointer*/
    if (!g) return NULL;

    /*check if node with that id is in the graph*/
    if ((index = find_node_index(g, fromId)) == -1) 
        return NULL;

    nconnections = node_getConnect(g->nodes[index]);

    /*we allocate the memory for the array of ids*/
    if (!(Ids = (long*) calloc(nconnections, (sizeof (long))))) 
        return NULL;

    /*for every node connected to g->nodes[index], we keep its id in Ids.*/
    for (i = j = 0; i < g->num_nodes; i++) {
        toId = node_getId(g->nodes[i]);
        if(graph_areConnected(g, fromId, toId)){
            Ids[j] = toId;
            j++;
        }
    }

    return Ids;
}

int graph_print(FILE *pf, const Graph * g) {
    int i, j, cha = 0;
    long *Ids;

    if (!pf || !g) {
        fprintf(stderr, "%s\n", strerror(errno));
        return -1;
    }


    for (i = 0; i < g->num_nodes; i++) {
        cha += node_print(pf, g->nodes[i]);

        /*get the array of ids of nodes connected to node with index i:*/
        if (!(Ids = graph_getConnectionsFrom(g, node_getId(g->nodes[i])))) {
            fprintf(stderr, "%s\n", strerror(errno));
            return -1;
        }

        /*print ids of all nodes connected to node with index i*/
        for (j = 0; j < node_getConnect(g->nodes[i]); j++) {
            cha += fprintf(pf, " %ld", Ids[j]);
        }

        free(Ids);
        fprintf(pf, "\n");
    }

    return cha;
}

Status graph_readFromFile(FILE *fin, Graph * g) {
    Node *n;
    int nnodes;
    char buff[MAX_LINE], name[NAME_L];
    int i;
    long id1, id2;
    int label;
    Status flag = OK;


    if (!fin || !g) return ERROR;

    if (!(n = node_init())) return ERROR;

    if (fgets(buff, MAX_LINE, fin) != NULL)
        if (sscanf(buff, "%d", &nnodes) != 1)return ERROR;

    for (i = 0; i < nnodes && flag == OK; i++) {

        if (fgets(buff, MAX_LINE, fin)) {

            if (sscanf(buff, "%ld %s %d", &id1, name, &label) == 3) {
                node_setId(n, id1);
                node_setLabel(n, label);
                node_setName(n, name);
                flag = graph_insertNode(g, n);
            } else flag = ERROR;

        } else flag = ERROR;
    }

    if (i < nnodes) flag = ERROR;

    while (flag == OK && (fgets(buff, MAX_LINE, fin) != NULL)) {
        if (sscanf(buff, "%ld %ld", &id1, &id2) == 2) {
            flag = graph_insertEdge(g, id1, id2);
        } else flag = ERROR;
    }

    node_free(n);

    if (!feof(fin))
        flag = ERROR;

    return flag;

}

/*******private functions****************/

/* It returns the index of the node with id nId1*/

int find_node_index(const Graph * g, int nId1) {
    int i;

    if (!g) return -1;

    for (i = 0; i < g->num_nodes; i++) {
        if (node_getId(g->nodes[i]) == nId1) return i;
    }

    /* ID not found*/
    return -1;
}

/* It returns an array with the indices of the nodes connected to the node
 *  whose index is index
 * It also allocates memory for the array.
 **/

int* graph_getConnectionsIndex(const Graph *g, int index) {
    int *array = NULL, i, j = 0, size;
    long idFrom, idTo;

    if (!g) return NULL;

    if (index < 0 || index > g->num_nodes) return NULL;

    /* get memory for the array*/
    size = node_getConnect(g->nodes[index]);
    array = (int *) malloc(sizeof (int) * size);

    if (!array) {
        /* print error message*/
        fprintf(stderr, "%s\n", strerror(errno));
        return NULL;
    }
    
    idFrom = node_getId(g->nodes[index]);

    /*assign values to the array with the indices of the connected nodes*/
    for (i = 0; i < g->num_nodes; i++) {
        idTo = node_getId(g->nodes[i]);
        if (graph_areConnected(g, idFrom, idTo) == TRUE) {
            array[j] = i;
            j++;
        }
    }

    return array;
}

Status graph_doubleCapacity(Graph *g) {
    Node **ppn = NULL;
    List **ppl = NULL;
    /* this function will only be called by 
     * graph_insertNode, and g will never be 
     * null, no need to check*/

    /* if ppn is null after tha call of realloc, 
     * it means memory is insufficient, but g->nodes 
     * and the memory it points to will be left untouched*/
    if (!(ppn = (Node**) realloc(g->nodes, 2 * g->capacity * sizeof (Node*))))
        return ERROR;

    if (!(ppl = (List**) realloc(g->plconnect, 2 * g->capacity * sizeof (List*)))) {
        /*if there is an error, set g->nodes back to its size and return error*/
        g->nodes = (Node**) realloc(ppn, g->capacity * sizeof (Node*));
        return ERROR;
    }

    /* both reallocs have been correct at this point, so if there was 
     * sufficient space after each of the arrays, the pointers ppn and 
     * ppl will be the same as g->nodes and g->plconnect. Otherwise, 
     * the momory has been moved and g->nodes and/or g->plconnect have 
     * been freed. Either way we can just do this: */

    g->nodes = ppn;
    g->plconnect = ppl;
    g->capacity *= 2;

    return OK;
}
