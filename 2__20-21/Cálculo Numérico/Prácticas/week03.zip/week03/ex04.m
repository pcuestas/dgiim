% break continue
for k= 1:6
    if k==4
        % continue
        break
    end
    disp(k)
end
