n = input('Introduce un número del 1 al 10');
if ((n<1) || (n>10))
    disp('El número debe ser del 1 al 10')
elseif mod(n,2)==0
    disp('El número es par.')
elseif n~=floor(n)
    disp('El número no es entero.')
else
    disp('El número es impar y entero.')
end