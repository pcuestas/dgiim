an = 1;
anp = 1;
n = 28
for k = 2:n
    an=((sqrt(1+an^2)-1)/an);
    anp=(anp/(sqrt(1+anp^2)+1));
    res=2^(k+1)*[an, anp];
    disp(['iteración ' num2str(k) ' -> ' num2str(res,' %.16f')])
end
