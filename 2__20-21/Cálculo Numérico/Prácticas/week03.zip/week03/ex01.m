for k= 1:20
    if k==13
        disp('hola')
    end
    disp(k^3)
end