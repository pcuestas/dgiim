% Hallar el primer valor de k tal que sqrt(1)+...+sqrt(k) > n

n=input('Introduce un valor de n:');
k=1;s=1;
while s<=n
    k=k+1;
    s=s+sqrt(k);
end

disp('El valor de k es: ')
disp(k)