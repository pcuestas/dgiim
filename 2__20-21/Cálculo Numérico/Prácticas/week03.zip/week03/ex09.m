A=[ 2 1; 1 -2];
b=[4; -3];

A_amp=[A,b];
% Alg Gauss-Jordan
B=rref(A_amp);
x=B(:,3);
disp(B)
disp(x)

% descomp LU (no es la descomop. pura, sino con pivotaje)
A= [1 2 1; 3 4 5 ; 5 8 1]
[L,U] = lu(A);
% l no es t. inferior
disp(L*U)
disp(L)

% podemos sacar la matriz de permutación con 3 argumentos:
[L,U,P] = lu(A)

disp(P*L*U)