h=1e-5;
x= linspace(1-h, 1+h, 100);
y=x.^5-5*x.^4+10*x.^3-10*x.^2+5*x-1;
figure(1)
plot(x,y)

%%% y = (x-1)^5
% resultado, como mucho: h^5 = 1e-25
% es imposible detectar una cancelación
% de 1e-25 con números de tamaño como 10

% Con números como 10, el máximo que se 
% puede detectar el 10*eps
hmax = (10*eps)^(1/5);
% del orden de este h está el límite para 
% detectar las cancelaciones
figure(2)
x= linspace(1-hmax, 1+hmax, 100);
y=x.^5-5*x.^4+10*x.^3-10*x.^2+5*x-1;
plot(x,y)
% afinamos un poco
figure(3)
h = 2*(10*eps)^(1/5);
x= linspace(1-h, 1+h, 100);
y=x.^5-5*x.^4+10*x.^3-10*x.^2+5*x-1;
plot(x,y)
