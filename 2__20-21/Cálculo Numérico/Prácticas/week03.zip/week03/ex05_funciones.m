% para llamar funciones, 
% la función debe estar definida 
% en otro fichero con el mismo 
% nombre que la función

% definamos la función 'fibo', que devuelve el n-ésimo núm. de fibonacci
for n=0:10
    fprintf('%d --> %d\n', n, fibo(n))
    %disp(['El número de Fibo. ' num2str(n) ' es ' num2str(fibo(n))])
end