function Fn = fibo(n)
% FIBO returns the n-th fibonacci number
if ((n==0) || (n==1))
    Fn=1;
    return;
elseif ((n<0) || (n~=floor(n)))
    Fn=-1; %error
    return;
end

j=1;
Fn=1;
Fprev=1;

while j<n
    j=j+1;
    next=Fn+Fprev;
    Fprev=Fn;
    Fn=next;
end

end

