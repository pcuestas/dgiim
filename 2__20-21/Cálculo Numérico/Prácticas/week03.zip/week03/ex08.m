% resolver sistemas Ax=b con matlab

A=[ 2 1; 1 -2];
b=[4; -3];
% x=[1; 2]

% con inversas (no eficiente)
disp( A^(-1) * b ) % = inv(A)*b

% sin inversa (más eficiente)
disp( A\b )

%significado:
B=[1 2; 0 1]

A/B %==A*B^(-1)
B\A %==B^(-1)*A