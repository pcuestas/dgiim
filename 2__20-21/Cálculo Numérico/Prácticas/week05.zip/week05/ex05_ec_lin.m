%% ecuación lineal
% x = 3*x - 8

x=1;
for k=1:6
    x=3*x-8; % esto tiende a menos inf, no tiene sentido
end

% rescribimos la ec. (x+8)/3=x

x=1;
for k=1:30
    x = (x+8)/3;% converge porque el coef de x es <1
end
format long
disp(x)
format short