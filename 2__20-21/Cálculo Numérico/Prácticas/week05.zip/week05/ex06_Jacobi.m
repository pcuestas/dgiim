% Idea vaga: 
% Los métodos iterativos para SEL son buenos
% con diagonal pequña y el resto de elementos 
% mucho más pequeños aún.
 
%% Método de Jacobi
% A*x=b, lo escribimos de la siguiente forma:
% x = D^-1 * (b - (A-D) * x), para toda D.
% Sea D la diagonal de A.

% Cómo hallar diagonales en Matlab:
    v = [1 2 4];
    diag(v);
    A = [1 2 3; 4 5 6; 7 8 9];
    diag(A);
    % entonces: 
    D = diag(diag(A));

% en lugar de escribir D^-1, hallamos la inversa a mano

%% Método de Jacobi
A = [5 2 1; -3 6 1; 2 3 5];
b = [10; 6; 20]; %sol= 1 1 3 - con matlab: x = A\b;

% definimos Ap = A-D
Ap = A - diag(diag(A));

% inversa de D 
Dinv = diag(A).^-1; % vector columna

% valor inicial
x = zeros(size(A,1),1);

% iteraciones del método
N=20;
for k = 1:N
  % x = D^-1 * (b - (A-D) * x)
    x = Dinv .* (b - Ap*x);
end

disp([x, [1;1;3]])

%{
Para que el método de Jacobi converja es suficiente
que los elementos de la diagonal "dominen" al resto de
los de su fila.
%}