
N=10000;
A=rand(N);

tic
for k = 1:N
    A(:,k) = 1;
end
toc

tic
for k = 1:N
    A(k,:) = 1;
end
toc