v=[1,-2,10,4];
disp(norm(v)) % norma 2
v = [1+3*1i; 5+1i];
disp(norm(v)) % norma 2

