v = [1 2 -3 0];
disp (norm(v,1)) % norma 1
disp(norm(v, Inf))
disp(max(abs(v)))
disp(norm(v,4))
disp(norm(v)==norm(v,2))

A = [1,2;3,4;5,6*1i];
A=rand(10);
%% norma inducida 1
no = norm(A,1); % máximo de las normas 1 de columnas
sum(A) ; % suma de las columnas
no1 = max(sum(abs(A)));
disp ([no, no1])

%% norma inducida infinito
no = norm(A,"inf");
no1 = max(sum(abs(A')));
disp ([no no1])