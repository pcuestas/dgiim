%% algoritmo para hallar una raíz cuadrada
% x_{n+1} = (x_n + N/x_n)/2

% ejemplo de raíz de 2
format long
x = 1;
N = 2;
for k = 1:6
    x = (x+N/x)/2
end
sqrt(2)