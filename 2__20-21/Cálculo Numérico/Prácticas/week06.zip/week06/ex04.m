% Método de Gauss-Seidel

N=12;
A = [5 2 1; -3 6 1; 2 3 5];
%A = [5 2 1; -3 1 1; 2 3 1];
b = [10; 6; 20];
n=size(A,1);
x=zeros(n,1);

for k=1:N
    for ii = 1:n
        %x(ii) = (b(ii)-sum(A(ii,1:ii-1)*x(1:ii-1))-sum(A(ii,ii+1:n)*x(ii+1:n)))/A(ii,ii);
         x(ii) = (b(ii)-sum(A(ii,:)*x)+A(ii,ii)*x(ii))/A(ii,ii);
    end
end
disp(['[',num2str(x'),']'])


% sum(A(2:1))