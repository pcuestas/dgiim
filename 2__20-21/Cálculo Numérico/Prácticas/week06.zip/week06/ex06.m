N = 10;% número de iteraciones

tol = 0.00001;% error relativo 

A = [5 2 1; -3 6 1; 2 3 5]; 

%A = [5 2 1; -3 1 1; 2 3 1]; %el método no converge con esto 
b = [10; 6; 20]; %sol= 1 1 3 - con matlab: x = A\b;
[x, err] = mgase(A,b,N,tol);

if err<tol
	disp('La aproximación de la solución es:')
	disp(x)
else
	disp ('No se consigue una aproximación con el error propuesto')
	if err>0.1
		disp('El error es grande')
		disp('Es posible que el método no converja')
	end
end
