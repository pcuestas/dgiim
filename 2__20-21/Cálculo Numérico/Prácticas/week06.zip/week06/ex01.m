A = [5 2 1; -3 6 1; 2 3 5]; 
A = [5 2 1; -3 1 1; 2 3 1]; %el método no converge con esto  
b = [10; 6; 20]; %sol= 1 1 3 - con matlab: x = A\b;

% definimos Ap = A-D
Ap = A - diag(diag(A));
% inversa de D 
Dinv = diag(A).^-1; % vector columna
% valor inicial
x = zeros(size(A,1),1); 
% iteraciones del método
N=100;

for k = 1:N
  % x = D^-1 * (b - (A-D) * x)
    x = Dinv .* (b - Ap*x);
end

disp(x)
