% Contraejemplo Gauss-Seidel no converge, Jacobi sí

% El programa NO es eficiente-usamos las funciones mjac y mgase
bet = (5+sqrt(21))/2
A = [1, 1, 2; bet, 1, 1 ; -5/2, 1/bet, 1]; % sí converge

x_exact = ones(size(A,1));
b = A*x_exact;

for k = 1:20
    [x,err] = mjac(A,b,k,0);
    e1 = norm(x-x_exact); %error absoluto con Jacobi
    
    [x,err] = mgase(A,b,k,0);
    e2 = norm(x-x_exact); %error absoluto con Gauss-Seidel
    
    disp(['k = ' num2str(k, '%02ld') ' -> J: ' num2str(e1, '%.5e') ' --- GS: ' num2str(e2, '%.5e') ])
end



N=40;
mjac(A,b,N,0)
 mgase(A,b,N,0)