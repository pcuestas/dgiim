% Comparación Gauss-Seidel/Jacobi en un caso en que
% la diagonal domina- GS MUCHO MEJOR

% El programa NO es eficiente-usamos las funciones mjac y mgase

n = 200;
% A = rand(n) -->seguramente no converja
A = rand(n) + (n-1) * eye(n); % sí converge

b = rand(n,1);
x_exact = A\b;

for k = 1:20
    [x,err] = mjac(A,b,k,0);
    e1 = norm(x-x_exact); %error absoluto con Jacobi
    
    [x,err] = mgase(A,b,k,0);
    e2 = norm(x-x_exact); %error absoluto con Gauss-Seidel
    
    disp(['k = ' num2str(k, '%02ld') ' -> J: ' num2str(e1, '%.5e') ' --- GS: ' num2str(e2, '%.5e') ])
end