% Ooperaciones con matrices vacías

N=12;
A = [5 2 1; -3 6 1; 2 3 5];
x = [1;1;3];
b = [10; 6; 20];
n=size(A,1);


rango = 1:3;
disp( A(1,rango) * x(rango) )

rango = 2:1;
disp( A(1,rango) * x(rango) ) % da 0