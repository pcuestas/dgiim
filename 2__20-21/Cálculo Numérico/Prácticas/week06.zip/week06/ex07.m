% Comparación Gauss-Seidel/Jacobi en un caso en que
% la diagonal domina

% El programa NO es eficiente-usamos las funciones mjac y mgase

A = [5 2 1; -3 6 1; 2 3 5]; 

b = [10; 6; 20]; %sol= 1 1 3 - con matlab: x = A\b;

x_exact = [1;1;3];

for k = 1:15
    [x,err] = mjac(A,b,k,0);
    e1 = norm(x-x_exact); %error absoluto con Jacobi
    
    [x,err] = mgase(A,b,k,0);
    e2 = norm(x-x_exact); %error absoluto con Gauss-Seidel
    
    disp(['k = ' num2str(k, '%02ld') ' -> J: ' num2str(e1, '%.5e') ' --- GS: ' num2str(e2, '%.5e') ])
end