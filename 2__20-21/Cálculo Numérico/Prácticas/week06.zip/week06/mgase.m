function [x, err] = mgase(A, b, Nmax, tol)
%MGASE método de Gauss-Seidel
    n=size(A,1);
    x=zeros(n,1);
    
    for k=1:Nmax
        x_old = x;
        for ii = 1:n
            %x(ii) = (b(ii)-sum(A(ii,1:ii-1)*x(1:ii-1))-sum(A(ii,ii+1:n)*x(ii+1:n)))/A(ii,ii);
             x(ii) = (b(ii)-sum(A(ii,:)*x)+A(ii,ii)*x(ii))/A(ii,ii);
        end
        err = norm(x-x_old)/norm(x_old); 
        if err<tol
            return
        end 
    end
end

