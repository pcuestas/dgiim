function [x, err] = mjac(A,b,Nmax,tol)
% Jacobi con número máximo de iteraciones,
% dada una tolerancia mínima

	Ap = A - diag(diag(A));
	% inversa de D 
	Dinv = diag(A).^-1; % vector columna
	% valor inicial
	x = zeros(size(A,1),1);

	for k = 1:Nmax
		x_old = x;
		x = Dinv .* (b - Ap*x);
		err = norm(x-x_old)/norm(x_old);
		if err<tol
			return 
		end
	end
end
