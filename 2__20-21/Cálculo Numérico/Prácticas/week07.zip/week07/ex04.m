% descomp QR reducida con G-S

A = [3, 9; 6, 4; 2, -1];
m = size(A,2);
Q = A;
R = zeros(m);

R(1,1) = norm(A(:,1));
Q(:,1) = A(:,1)/R(1,1);

for k = 2:m
    u_k = A(:, k);
    for j = 1:k-1
        R(j,k) = (Q(:,j)' * A(:,k));
        u_k = u_k - R(j,k)*Q(:,j);
    end
    R(k,k) = norm(u_k);
    Q(:,k) = u_k / R(k,k);
end

format rat
disp(Q);
disp(R);
format short

norm(A-Q*R)

Q(:,1)'*Q(:,2) %cero
disp([norm(Q(:,1)), norm(Q(:,2))])