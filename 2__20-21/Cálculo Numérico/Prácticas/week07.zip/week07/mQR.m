function [Q,R] = mQR(A)
% mQR descomposición QR reducida con Gram-Schmidt
  
m = size(A, 2);
R = zeros(m);
Q = A;
R(1,1) = norm(A(:,1));
Q(:,1) = A(:,1)/R(1,1);

for k = 2:m
    u_k = A(:, k);
    for j = 1:k-1
        R(j,k) = (Q(:,j)' * A(:,k));
        u_k = u_k - R(j,k)*Q(:,j);
    end
    R(k,k) = norm(u_k);
    Q(:,k) = u_k / R(k,k);
end


end