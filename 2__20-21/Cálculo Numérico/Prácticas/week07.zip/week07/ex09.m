A = [1,2;3,4];

A = rand(1000);

tic
[Q,R] = mQR(A);
toc

tic
[Q,R] = mQR2(A);
toc