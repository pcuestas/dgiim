function [Q,R] = mQR2(A)
%mQR2 desc. QR reducida con el método de Householder
    n = size(A,1);
    Q = eye(n);
    R = A;
    
    for k = 1:n-1
        x = R(k:n ,k);
        v = zeros(n,1);
        v(k:n) = vh(x); % vector de Householder 
        % dim Qt = n - es la de Householder completada con k-1 unos
        Qt = eye(n) - 2 * (v * v');
        R = Qt*R;
        Q = Qt*Q; % se va guardando la Q, pero es ortogonal
        % Para que sea exactamente triangular (quitamos los errores de los ceros)
        R(k+1:n , k) = zeros(n-k,1);
    end
    Q = Q';
end

