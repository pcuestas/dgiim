a = [1+i; 3];
b = [2-i; 3+7*i];
 
% en álgebra lineal el p. escalar se defie como
transpose(a)*conj(b)

% en el resto de áreas:
conj(transpose(a))*b;
a' * b


% para que salga como en los libros, basta escribirlo al revés:
%       <a,b> = b' * a
b' * a


...............


%{
v2 = u2 + a2*v1

<v2,v1> = 0 = <u2, v1> + a2*<v1,v1>
%}