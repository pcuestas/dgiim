% Matrices de Householder: H = I-2*v*v'
% matriz de la simetría respecto al subespacio
% perpendicular a L(v).
% Matriz ortogonal o unitaria y simétrica: H^-1 = H' = H

N = 1000;

v = rand(N,1);
v = v/norm(v);
H = eye(N)-2*(v*v');
norm(eye(N)-H*H)