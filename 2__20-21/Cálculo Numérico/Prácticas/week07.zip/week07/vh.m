function [v] = vh(x)
    %VH dado x, halla el v para construir la matriz de Householder 
    % tal que H*x sea todo ceros excepto la primera coordenada
    % H = I - 2 * v * v'
    v = x;
    
    if v(1)>0
        v(1) = v(1) + norm(x);
    else
        v(1) = v(1) - norm(x);
    end
    
    v = v / norm(v);

end