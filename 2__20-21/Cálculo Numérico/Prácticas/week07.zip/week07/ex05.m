% descomp QR reducida con G-S

A = [3, 9; 6, 4; 2, -1];

A = rand(1000);

tic
[Q,R] = mQR(A);
toc

Q * Q';% nada coherente
Q' * Q;% identidad

tic
[Q,R] = qr(A);
toc

Q * Q'; % identidad
Q' * Q; % identidad