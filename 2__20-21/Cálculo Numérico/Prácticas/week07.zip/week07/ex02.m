% Gram-Schmidt

A = [3, 9; 6, 4; 2, -1];
A= [1+1i, 3*1i;7-1i, 2021];
m = size(A,2);
Q = A;
Q(:,1) = A(:,1)/norm(A(:,1));

for k= 2:m
    u_k = A(:, k);
    for j = 1:k-1
        u_k = u_k - (Q(:,j)' * A(:,k))*Q(:,j);
    end
    Q(:,k) = u_k / norm(u_k);
end

disp(Q);
Q(:,1)'*Q(:,2) %cero

disp([norm(Q(:,1)), norm(Q(:,2))])
