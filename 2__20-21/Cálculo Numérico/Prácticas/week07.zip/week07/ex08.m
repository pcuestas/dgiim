% Descomposición QR con el método de Householder

%{ 
Idea: A, 1ª columna, con una matriz de Householder,
se puede hacer que se aplica en algo proporcional a e_1.
Entonces H*A tiene ceros por debajo del a_{1,1}

Repetimos el argumento para k = 1:n-1
por debajo de a_{k,k}... -> H_{n-1}*...*H_1*A es triangular
superior.
De modo que (ortogonal)*A = R --> A = Q*R 
%}

A = [1,1,2; 1,5,1; 1,1,1; 1,5,0];
n = size(A,1);
Q = eye(n);
R = A;

for k = 1:n-1
    x = R(k:n ,k);
    v = zeros(n,1);
    v(k:n) = vh(x); % vector de Householder 
    % dim Qt = n - es la de Householder completada con k-1 unos
    Qt = eye(n) - 2 * (v * v');
    R = Qt*R;
    Q = Qt*Q; % se va guardando la Q, pero es ortogonal
    % Para que sea exactamente triangular (quitamos los errores de los ceros)
    R(k+1:n , k) = zeros(n-k,1);
end
Q = Q';

Q
R
