% dado un vector x, es fácil construir una matriz
% de Householder H tal que H*x da todo ceros excepto
% la primera coordenada. H = I - 2 * (v*v')

x = [2;3;5;ones(10,1)];

v = vh(x);

H = eye(13) - 2*(v*v');

disp(H*x)