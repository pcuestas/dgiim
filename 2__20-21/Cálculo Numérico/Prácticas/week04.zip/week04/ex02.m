A=[1,2,1; 3,4,5; 5,8,1];

n=size(A,1);

U = A; L = eye(n);
for k = 1:n-1
    for ii = k+1:n
        L(ii,k) = U(ii,k)/U(k,k);
        % cambiamos la j por k:n
        U(ii,k:n) = U(ii,k:n) - L(ii,k)*U(k,k:n);
    end
end

disp('L = ')
disp(L)
disp('U = ')
disp(U)
disp('L*U-A = ')
disp(L*U-A)