function [x] = utrs(A,b)
    % UTRS soluciona el sistema Ax=b donde 
    % A es triangular superior
    n=size(A,1);
    x=zeros(n,1);
    x(n)=b(n)/A(n,n);
    for k=n-1:-1:1
        j=k+1:n;
        x(k)=(b(k) - (A(k,j)*x(j)))/A(k,k);
        %x(j) es columna, A(k,j) es fila
    end
end

