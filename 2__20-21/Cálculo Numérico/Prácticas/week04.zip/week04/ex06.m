A = [2,3,5; 0,4,1; 0,0,1]; %tr inf
% tomamos solución: 1,0,3
b = [17;3;3];

utrs(A,b)

A = triu(rand(20));
t = rand(20,1);
b = A*t;
max(abs(utrs(A,b)-x))
utrs(A,b)-t