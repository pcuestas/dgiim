A=[1,2,1; 3,4,5; 5,8,1];
A=rand(4)
n=size(A,1);
U = A; L = eye(n);
for k = 1:n-1
    for ii = k+1:n
        L(ii,k) = U(ii,k)/U(k,k);
        for j = k:n
            U(ii,j) = U(ii,j) - L(ii,k)*U(k,j);
        end
    end
end

disp('L = ')
disp(L)
disp('U = ')
disp(U)
disp('L*U-A = ')
disp(L*U-A)