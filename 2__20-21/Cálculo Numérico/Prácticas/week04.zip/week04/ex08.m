
v=[3,5,7,-100];
[m,j]=max(abs(v))