A = [2,0,0; 1,2,0; 2,3,5]; %tr inf
% tomamos solución: 1,1,2
b = [2;3;15];

ltrs(A,b);

A = tril(rand(20));
t = rand(20,1);
b = A*t;
max(abs(ltrs(A,b)-x))
ltrs(A,b)-t
