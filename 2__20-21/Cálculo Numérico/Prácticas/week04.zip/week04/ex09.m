A = [1,2,1; 3,4,5; 5,8,1];
n=size(A,1);
U=A; L=eye(n); P=eye(n);
for k=1:n-1
    [m,j] = max(abs(U(k:n,k)));
    if j~=1
        r=j+k-1;
        %normal: temp=U(k,k:n);U(k,k:n)=U(r,k:n);U(r,k:n)=temp;
        %más elegante
        U([k,r],k:n) = U([r,k],k:n);
        L([k,r],1:k-1) = U([r,k],1:k-1);
        P([k,r],:) = P([r,k],:);
    end
    j=k:n;
    for ii = k+1:n
        L(ii,k) = U(ii,k)/U(k,k);

        U(ii,j) = U(ii,j) - L(ii,k)*U(k,j);
    end
end