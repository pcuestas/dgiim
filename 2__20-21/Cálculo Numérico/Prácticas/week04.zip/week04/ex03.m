A=[1,2,1; 3,4,5; 5,8,1];
A=rand(6);
Ap=A;
n=size(A,1);
%reescribimos L U en A, ignorando la diagonal de 1 en L
for k = 1:n-1
    j=k+1:n;%hay que empezar en k+1 para no escribir en U por debajo de la diagonal
    for ii = k+1:n
        A(ii,k) = A(ii,k)/A(k,k);
        % cambiamos la j por k:n 
        A(ii,j) = A(ii,j) - A(ii,k)*A(k,j);
    end
end

U = triu(A);
L = tril(A,-1)+eye(n);
disp('U = ')
disp(U)
disp('L = ')
disp(L)
max(max(abs(L*U-Ap)))% max actúa por columnas 
                     % primero
% el máximo de los errores es muy pequeño



fprintf('---------------\n')