% Resuelve sistemas lineales con la descomposición lu
A = [1,2,1; 3,4,5; 5,8,1];
b = [4;12;14];

[L,U] = mlu(A);

y = ltrs(L,b);
x = utrs(U,y);

disp(x);
disp (A*x-b);