function [x] = ltrs(A,b)
    % LTRS soluciona el sistema Ax=b donde 
    % A es triangular inferior
    n=size(A,1);
    x=zeros(n,1);
    x(1)=b(1)/A(1,1);
    for k=2:n
        j=1:k-1;
        x(k)=(b(k) - (A(k,j)*x(j)))/A(k,k);
        %x(j) es columna, A(k,j) es fila
    end
end

