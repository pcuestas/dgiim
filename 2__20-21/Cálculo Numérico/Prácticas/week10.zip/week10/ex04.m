N = 2;
x = 3;
for k=1:N
    x = x+sin(x);% derivada primera y segunda == 0 
end
err = x - pi;
disp(['Error absoluro: ' num2str(err)])


%% buscar extrapolación de Richardson