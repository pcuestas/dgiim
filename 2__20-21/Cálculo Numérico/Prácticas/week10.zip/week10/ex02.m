% modo QR para hallar todos los autovaloers
% de una matriz simétrica def. positiva con autovalores simples

%Autovaloes:  8, 6, 4, 2
A = [5, 0, -2, 1;0,5,-1,2;-2,-1,5,0;1,2,0,5];

%método: descomponer QR la matriz, redefinir la matriz como R*Q
% y repetir.
% realmente, R*Q = Q^-1 * A * Q (cambio de base de A)
N = 15;
n = size(A,1);
for k = 1:N
    [Q,R] = qr(A);
    A = R*Q; % poco eficiente, muchas flop. 
end
disp('Aproximación de los autovalores')
disp(diag(A))
%disp('Aproximación de los autovectores')
%Q*v