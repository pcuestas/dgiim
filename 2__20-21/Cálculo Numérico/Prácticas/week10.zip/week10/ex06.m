% método de la bisección

f = @(x) x^2 - 2; % fcn. anónima

N = 10;
a = 1;
b = 2;

for k=1:N
    c = (a+b) / 2;
    if f(a)*f(c) < 0
        b = c;
        disp(['Izquierdo ' num2str(a) ' , ' num2str(b)])
    else
        a = c;
        disp(['Derecho ' num2str(a) ' , ' num2str(b)])
    end
end
err = (a+b)/2 - sqrt(2);
disp(['Error absoluto ' num2str(err)])