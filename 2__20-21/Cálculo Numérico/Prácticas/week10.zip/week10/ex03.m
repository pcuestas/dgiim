% x_{n+1} = g(x_n) bajo buenas condicines converge a un cero de
% f(x) = g(x) - x
format long
N = 4;
x = 1;
for k = 1:N
    x = (x+2/x)/2; % aquí el tamaño de la derivada es lo menor posible
end
disp(x)
err = x - sqrt(2);
disp(['Error absoluto: ', num2str(err)])
disp('-----------')

x = 1;
for k = 1:N % esta función es peor, converge más lento
    x = x-1/2*(x^2-2);
end
disp(x)
err = x - sqrt(2);
disp(['Error absoluto: ', num2str(err)])
disp('-----------')
format short