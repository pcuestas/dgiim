function  x = mnewton(f, df, x0, N)
% mtodo de Newton-Raphson
x = x0;
for k = 1:N
    x = x- f(x) / df(x);
end

