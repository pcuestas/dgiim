function res = newf(x)
    res = x^2 - 2;
end

