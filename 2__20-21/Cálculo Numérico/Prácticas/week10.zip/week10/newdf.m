function res = newdf(x)
    res = 2*x;
end

