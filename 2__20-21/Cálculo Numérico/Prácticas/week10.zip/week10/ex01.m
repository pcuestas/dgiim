A = [5, 0, -2, 1;0,5,-1,2;-2,-1,5,0;1,2,0,5];

%método de la potencia
v = rand(4,1);

for k = 1:10
    v = A*v;
    v = v/norm(v);
    v'*A*v
end