% La convergencia de punto fijo se puede acelerar con la
% extrapolación de Aitken.
% x_{n+1} = x_n - (g(x_n) - x_n)^2 / (g(g(x_n)) - 2 g(x_n) + x_n)
% esto acelera la iteración x_{n+1} = g(x_n)
format long
g = @(x) x-1/2*(x^2-2); 
N = 3;
x = 1;
xa = 1;
for k = 1:N % esta función es peor, converge más lento
    x = g(x);
    xa = xa -(g(xa)-xa)^2/(g(g(xa))-2*g(xa) + xa);
end
disp(x)
err = x - sqrt(2);
err2 = xa - sqrt(2);
disp(['Error absoluto: ', num2str(err)])
disp(['Error absoluto2: ', num2str(err2)])
disp('-----------')
format short