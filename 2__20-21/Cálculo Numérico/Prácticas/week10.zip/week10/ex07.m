format long
Nmax = 200;
tol = 1e-4;
x = 1;
for k = 1:Nmax
    xn = x-1/2*(x^2-2);
    if abs(xn - x) < tol
        errap = xn - x;
        x = xn; 
        break;
    end
    x = xn;
end
fprintf('%d iteraciones. Error = %.6e.\n aprox %.10e', k, x - sqrt(2), errap)