% un = ones(50);
% A = [0*un, 1*un; 1*un, 3*un];
% imshow(A, [0,3])

% Newton a f(x) = x^3 -2
z0 = 2^(1/3);
z1 = z0*exp(2*pi*1i/3);
z2 = z0*exp(-2*pi*1i/3);

% Elegimos valores iniciales complejos con parte real e imaginaria en
% [-3/2, 3/2]

N = 400;
% N filas variando entre -3/2 y 3/2
A = meshgrid(linspace(-3/2, 3/2, N), 1:N);
% Lo mismo con la parte imaginaria por columna
A = A + 1i*A';

% A tiene todos los x_0 que quiero seleccionar

% aplicamos Newton
for l = 1:30
    A = 2*(A.^3+1)./A.^2/3;
end
t = 1e-2;
C = (abs(A-z0)<t) + 2*(abs(A-z1)<t) + 3*(abs(A-z2)<t);
imshow(C, [0,3])