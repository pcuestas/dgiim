mnewton(@newf, @newdf, 1, 4)

f = @(x) x^2 - 2;
df = @(x) 2*x;
mnewton(f, df, 1, 4)
% también se puede usar feval(f, x) para evaluar f(x)