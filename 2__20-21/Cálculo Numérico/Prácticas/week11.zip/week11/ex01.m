% Forma baricéntrica de la interpolación

% Para nodos equiespaciados, se puede tomar 
% w_j = (-1)^j *C(n, j)  --- salvo una constante, que se puede obviar para 
%                            este método (por la división)

%Interpolemos y = sen(x) en [-pi, pi] con n+1 nodos equiespaciados
a = -pi;
b =  pi;
n = 10;
x = linspace(a, b, n+1);
y = sin(x);
% w_j:
w = zeros(n+1, 1);
for j = 0:n
    w(j+1) = (-1)^j*nchoosek(n, j); % nùmero C(n, j)
end

t = linspace(a, b, 300);

figure(1)
plot(x, y, 'ro', ... dibuja los puntos de interpolación
    t, sin(t), 'r--'); 
hold on
plot(t, larg_bar(x, y, w, t), 'b');
hold off

figure(2)
plot(t, sin(t)- larg_bar(x, y, w, t))