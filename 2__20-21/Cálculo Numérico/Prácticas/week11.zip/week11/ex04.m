% Un polinomio se puede representar por una matrix
% fila que da sus coeficientes
p1 = [1,1,1]; % x^2+x+1
p2 = [1,-1,0,1,-1]; % x^4+-x^3+x-1
%producto de polinomios:
p = conv(p1, p2)
%evaluar un polinomio en una x
polyval(p, [0:2])

% en matlab el polinomio de interpolación se puede
% calcular con: polyfit(x, y, n)

n = 4; x = linspace(-pi,pi,n+1); y = sin(x);
cpi = polyfit(x, y, n);...pol interpolador
t = linspace(-pi, pi, 300);
figure(1);
plot(x, y, 'bo', t, sin(t), 'r--'); hold on;
plot(t, polyval(cpi, t), 'k'); hold off;


% si en polyfit ponemos n menor, nos devuelve el 
% resultado de mínimos cuadrados
n = 10; x = linspace(-pi,pi,n+1); y = sin(x);
cpi = polyfit(x, y, 3);...pol interpolador
t = linspace(-pi, pi, 300);
figure(2);
plot(x, y, 'bo', t, sin(t), 'r--'); hold on;
plot(t, polyval(cpi, t), 'k'); hold off;
