% Interpolar y=x en valores enteros en [-K,K]
K = 10;
a = -K;
b = K;
x = a:b;
y = x;

% por este pequeño cambio, el polinomio 
% interpolador varía muchísimo (hay muchos nodos):
y(K+1) = 1; ... realmente es 0

sc = spline(x, y); %pol cúbico a trozos
% sin importar lo grande que sea la perturbación,
% sigue siendo una buena aproximación

t = linspace(a, b, 300);
figure(1)
plot(x, y, 'bo',...
    t, ppval(sc,t), 'k');