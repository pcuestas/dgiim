function w = wj(x)
    %WJ a partir de los nodos x_j
    n = length(x) - 1;
    w = ones(1, n+1);
    for j = 0:n
        temp = x(j+1) - x;
        temp(j+1) = []; %valor vacío, quitamos una coordenada a la variable
        w(j+1) = 1 / prod(temp);
    end
end

