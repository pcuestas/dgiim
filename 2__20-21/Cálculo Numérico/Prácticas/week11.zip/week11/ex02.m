a = -pi;
b =  pi;
n = 8;
x = linspace(a, b, n+1);
y = sin(x);
% w_j:
w = zeros(1, n+1);
for j = 0:n
    w(j+1) = (-1)^j*nchoosek(n, j); % nùmero C(n, j)
end
disp(w);
disp(wj(x));
disp(w./wj(x))
w = wj(x);
t = linspace(a, b, 300);

figure(1)
plot(x, y, 'ro', ... dibuja los puntos de interpolación
    t, sin(t), 'r--'); 
hold on
plot(t, larg_bar(x, y, w, t), 'b');
hold off

figure(2)
plot(t, sin(t)- larg_bar(x, y, w, t))