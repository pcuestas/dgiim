% Fenómeno de runge
% Ejemplo Runge; la interpolación de los valores de 
% y = 1/(1+x^2) en [-5, 5] con nodos equiespaciados
% no aproxima. ||f - P_n||_\infty -> \infty
n = 15; 
f =@(x) 1 ./ (1 + x.^2);
x = linspace(-5,5,n+1); y = f(x);

cpi = polyfit(x, y, n); % pol de interpolación

figure(1); 
t = linspace(-5, 5, 300);
plot(t, f(t), 'r--', ...
     t, polyval(cpi, t, n), 'g')