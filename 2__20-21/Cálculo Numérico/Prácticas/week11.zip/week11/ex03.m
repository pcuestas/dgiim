% Interpolar y=x en valores enteros en [-K,K]
K = 10;
a = -K;
b = K;
x = a:b;
y = x;

% por este pequeño cambio, el polinomio 
% interpolador varía muchísimo (hay muchos nodos):
y(K+1) = 0.01; ... realmente es 0

w = wj(x);
t = linspace(a, b, 300);
figure(1)
plot(x, y, 'bo') 
hold on
plot(t, larg_bar(x, y, w, t), 'g');
hold off