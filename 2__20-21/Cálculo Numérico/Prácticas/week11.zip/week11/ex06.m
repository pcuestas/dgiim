% Si la interpolación puede ser un desatre
% ¿Cuál es la alternativa?
% En pocas palabras se usa interpolación de 
% grado bajo a trozos con condiciones extra
% para asegurar cierta regularidad.
% Los splines(cúbicos naturales) dan de los 
% mejores resultados. 
% Son polinomios cúbicos a trozos.
n = 10; 
f =@(x) 1 ./ (1 + x.^2);
x = linspace(-5,5,n+1); y = f(x);

cpi = polyfit(x, y, n); % pol de interpolación
sc = spline(x, y); %pol cúbico a trozos

figure(1); 
t = linspace(-5, 5, 300);
plot(t, f(t), 'r--', ...
     t, ppval(sc, t), 'b',...
     t, polyval(cpi, t, n), 'g')