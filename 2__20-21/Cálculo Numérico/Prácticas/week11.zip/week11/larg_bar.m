function res = larg_bar(x, y, w, t)
    % interpolación (forma baricéntrica)
    % dados los puntos (x_j,y_j) y los w_j
    % t puede ser un vector de puntos donde calcular el valor 
    n = length(x) - 1;
    N = 0;
    D = 0;
    for j = 1:n+1
        v = w(j) ./ (t-x(j));
        N = N + y(j)*v;
        D = D + v;
    end
    
    res = N ./ D;

end

