rand('seed', 0);
N = 6;
x = (1:N)';
y = 2*x + 4*rand(N,1)

rrerr(x, y)
rrerr(y, x)
