A = rand(100,200);

[U, D, V] = svd(A);

for r = 99:-1:1
    D(r+1,r+1) = 0;
    Ar = U*D*V';
    err(r) = norm(A-Ar,'fro');
end
plot(err)