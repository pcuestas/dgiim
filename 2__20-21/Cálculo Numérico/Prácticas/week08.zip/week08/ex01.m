A = [1,2;1,1;3,1];
b = [2;8;6];
% Ax = b no compatible
% sol de min cuadrados: minimizar ||Ax-b||
disp('Solución de matlab');
A\b
disp('Con la pseudoinversa')
inv(A'*A)*A'*b

[Q,R] = qr(A)
disp('Con QR (sin simplificar)')
inv(R'*R)*R'*Q'*b
disp('Con QR (simplificado)')
m = size(A,2);
T = R(1:m,:);% R gorro
Qm = Q(:,1:m);% Q gorro
inv(T)*Qm'*b