% SVD con matlab
% A = U*D*V'
% U, V ortogonales (o unitarias)
% D "diagonal" (quizá completada con zeros) con diagonal positiva
rand('seed',0);
A = rand(3, 2)
[U,D,V] = svd(A)
norm(U*D*V'-A, 'fro')% norma de Frobenius
