function [res] = rrerr(x, y)
%RRERR máximo error al utilizar regresión lineal
N = size(x, 1);
A = [ones(N,1), x];
c = inv(A'*A)*A'*y;
res = max(abs(c(1)+c(2)*x - y));
end