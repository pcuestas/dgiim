A = [1,2;1,1;3,1];
b = [2;8;6];
% Ax = b no compatible
% sol de min cuadrados: minimizar ||Ax-b||
disp('Solución de matlab');
A\b
% ahora con valores singulares
[U,D,V] = svd(A);
[n,m] = size(A);
E = diag(diag(D));
xb = V * inv(E) * U(:,1:m)' * b