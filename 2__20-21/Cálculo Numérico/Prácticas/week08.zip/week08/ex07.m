% teorema de Eckart-Young-Mirsky
% Aproximar una matriz por otra de rango pequeño

% Idea: si ponemos a cero los últimos valores principales 
% (de los más pequeños), tendremos una buena aproximación 
% por una matriz de rango bajo

% es óptima en el sentido de norma de Frobenius mínima

A = [1,2,3; 1,1,2; 3,1,4; 3,1,4]; % rg(A) = 2

r = 2;
[U,D,V] = svd(A);
for k = r+1:min(size(A))
    D(k,k) = 0
end
Ar = U*D*V';
Ar

