% Regresión lineal es un caso especial de mínimos cuadrados
% y_i = a + b*x_i para que se cumpla aproximadamente
% Y = A*(a,b) queremos hallar a y b
N = 6;
x = (1:N)';
y = 2*x + 4*rand(N,1);
A = [ones(N,1),x];

c = inv(A'*A)*A'*y

plot (x, y, 'o')
hold on 
plot(x, c(1)+c(2)*x)
hold off