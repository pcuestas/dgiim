rand('seed',0);
A = rand(5, 7);
disp('Llamada completa')
[U,D,V] = svd(A)
w = diag(D)
disp('Valores singulares')
v = svd(A)
