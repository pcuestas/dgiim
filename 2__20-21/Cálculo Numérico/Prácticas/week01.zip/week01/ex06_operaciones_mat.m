% Operaciones raras con matrices
A = [1 0 pi;200*pi -pi pi]
sin(A) % sin de cada elemento de A

%% eps = épsilon máquina; es el error relativo más pequeño distinguible
eps
(.1+eps)-.1
(10+eps)-10

%% más operaciones

log(A+20)

A = [1 0 1;2 -1 1];

A.*A % poniendo un '.' antes de la operación se hace elemento a elemento
A.^2
[1,2].*[6,3]