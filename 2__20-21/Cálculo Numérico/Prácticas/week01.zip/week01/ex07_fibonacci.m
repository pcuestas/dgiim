% Números de Fibonacci
n=20;
F=[1 1;1 0];
A= F^n;
disp('El número de Fibonacci es')
disp(A(1,2)) % es el número de ficonacci 20   (20-1)

%%
n=input('Introduce n');
F=[1 1;1 0];
A= F^n;
disp('El número de Fibonacci es')
disp(A(1,2)) % es el número de ficonacci n-ésimo