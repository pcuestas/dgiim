% Matrices

A = [1, 0, 1; 2, -1, 1]; %las ',' se pueden sustituir por espacios
B = [-2 1 0; 3 1 1];

% Suma de matrices
A + B
% Traspuesta y conjugada
A'
% Producto de A por la traspuesta de B
A*B'
% La matriz nula
zeros(2,3)
% La matriz de unos
ones(2,3)
% La matriz identidad
eye(4)

