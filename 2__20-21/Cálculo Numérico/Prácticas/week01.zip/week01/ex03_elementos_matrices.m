% def
A = [1, 0, 1; 2, -1, 1]; 
B = [-2 1 0; 3 1 1];
% Acceso a los elementos (fila, columna)
A(2,1) %se empieza a contar por 1
A(2,2)
A(2,3)
%% definición de matrices
% La matriz de Pauli sigma2
s_2 = [0,-i; i, 0];
% La matriz de Dirac gamma_2
g_2=[zeros(2) -s_2 ; s_2, zeros(2)];

% otro ejemplo
A=[1 2;3 4]
B=[zeros(2) -A ; A, zeros(2)]