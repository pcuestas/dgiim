% Dim y porciones de matrices
A=[1 0 1; 2 -1 1]
size(A)

v=1:3
size(v)
length(v) % solo se obtiene el distinto de 1

% Porciones de matrices
A([1 2],[2 3]) % (columnas, filas). equivalente a:
A(1:2, 2:3)

A(1, :) % solo ':' significa todas las (filas/columnas) posibles

% Se pueden sumar números con matrices
A+7*ones(2,3)
A+7