format long
% aproximación del número e
n=50;
(1+1/n)^n

n=2*n;
(1+1/n)^n

% aprox. sin 1

apr=1-1/factorial(3)+1/factorial(5)-factorial(7);

sin (1)-apr