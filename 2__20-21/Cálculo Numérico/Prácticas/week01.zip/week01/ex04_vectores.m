v=[1,2,3]
w=[1;2;3] % columna

v=[1:3] % ambos incluidos (no hace falta usar corchetes)
v= 2.7:4 % va de uno en uno y para cuando lo supera

v=[1:2:17] % números del 1 al 17 con un incremento de 2
v= 2:.5:5

v = linspace(2,5,8) % 8 números entre 2 y cinco. Equivalente a lo siguiente
v = 2:(5-2)/(8-1):5
