% autovalores 4, 1+-i, 1
A1 = [-7,6,-8,5;-16,10,-13,10;-5,2,-2,3;-8,6,-8,6];

A = A1;
v = rand(size(A,1),1);
v = v/norm(v);

N = 8;
for k = 1:N
    vn = A*v;
    v = vn/norm(vn);
end

disp('Aproximación del autovector')
disp(v)
disp('Aproximación del autovalor')
disp(v' * A * v)