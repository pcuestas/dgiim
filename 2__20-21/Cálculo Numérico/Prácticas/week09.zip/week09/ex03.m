% autovalores 4, 3, 2, 1
A2 = [-1, 3, -5, 2; -7, 7, -7, 4; -1, 1, 1, 0; -2, 3, -5, 3];
% ahora la convergencia es más lenta
        % porque el segundo mayor autoavalor está más cerca del
        % mayor (4-3)/4
        
A = A2 - 2*eye(size(A2, 1));
%ahora la rapidez de la convergencia depende de (2-1)/2 (más rápido)
v = rand(size(A,1),1);
v = v/norm(v);

N = 10; 
for k = 1:N
    vn = A*v;
    v = vn/norm(vn);
end

disp('Aproximación del autovector')
disp(v)
disp('Aproximación del autovalor')
disp(v' * A * v + 2)