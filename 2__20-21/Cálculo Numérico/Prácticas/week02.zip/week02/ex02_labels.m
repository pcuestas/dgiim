x=0:0.03:2*pi;
plot(x, sin(x))
xlabel('Eje x')
ylabel('yyyyy')
title('gráfica del seno')