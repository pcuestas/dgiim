% Superposición de gráficas
x1=0:0.03:2*pi;
y1=sin(x);
x2=0:.5:2*pi;
y2=cos(5*sqrt(x2));

plot(x1, y1, 'k-.', 'linewidth', 1.2)
hold on
plot(x2, y2, 'b-', 'linewidth', 2)
hold on
plot(x1, cos(x), 'm-')
hold off
% plot (x1,x1)