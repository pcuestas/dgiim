% Superposición de gráficas
x1=0:0.03:2*pi;
y1=sin(x);
x2=0:1:2*pi;
y2=cos(5*sqrt(x2));
figure(1)
plot(x1, y1, x2, y2)
figure(2)
plot(x1, y1, 'g--', x2, y2, 'b-.', 'linewidth', 2)