x = linspace(0,2*pi,40);
y = sin(x); % el seno aplicado a cada valor de la x
plot(x, y);
y1=10*exp(-x).*sin(x.^2).*x.*(1+x).^-1;
plot(x, y, x, y1);
% color: "inicial": c, m, y, r, g, b, w, k
% linewidth: número
plot(x, y1, 'r', 'LineWidth', 2)
%estilo de línea: -, --, :, -. 
plot(x, y1, 'k-.', x,y, 'm:', 'LineWidth',1.5)
%tipo de punto: o,s
figure(1)
plot(x, y1, 'r-o', x,y, ':s', 'LineWidth', 1.5)
figure(2)
plot(x, y1, 'r-.s')