% se terminan con end
for k = 1:10
    %disp(k)
end

for k = [1 3 4 5 2]
    %disp(k)
end

for k = [1, 2; 3, 4] % lo recorre por columnas
    disp(k)
    disp('s')
end