x=linspace(-1,1,100);
y1=sqrt(1-x.^2);
y2=-sqrt(1-x.^2);
figure(1)
plot(x, y1, 'k-', x, y2, 'k-')

% Más elegante
t = linspace(0, 2*pi, 200);
figure(2)
plot(cos(t), sin(t))
axis('square')

figure(3)
plot(10*cos(t), sin(t))
axis square

figure(4)
plot(10*cos(t), sin(t))
axis equal % misma escala en los ejes

figure(5)
plot(cos(t), sin(t), 'LineWidth', 2)
axis('equal') % misma escala en los ejes

figure(6)
plot(cos(t), sin(t), 'LineWidth', 3)
axis square
axis off % se ocultan los ejes