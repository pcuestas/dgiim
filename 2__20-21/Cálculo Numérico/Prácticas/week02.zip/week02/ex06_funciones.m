[x, y] = meshgrid(linspace(-pi,pi,30), linspace(-1,1,20));

z = (1-y.^2).* sin(x);

figure(1)
mesh(x,y,z)

figure(2)
eje=[0,0,1]
ang=45
rotate(surf(x,y,z), eje, ang)
%surf(x,y,z)
%view([-30 30]) %% ángulos en grados: con el eje x , con el eje z

xlabel('eje x')
ylabel('eje y')
zlabel('eje z')
title('título')
colormap parula
% axis off