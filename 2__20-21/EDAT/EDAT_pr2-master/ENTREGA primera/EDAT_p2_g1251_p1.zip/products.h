#ifndef PRODUCTS_H
#define PRODUCTS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"


int ProductsStock();
int ProductsFind();

#endif